import fs from "node:fs";
const src = fs.readFileSync(new URL("../src/cues.generated.ts", import.meta.url), "utf8");
const cues = JSON.parse(src.slice(src.indexOf("= [", src.indexOf("export const cues")) + 2, src.lastIndexOf("]") + 1));
const FPS = 30;
const cf = (i) => Math.round(cues[i - 1].start * FPS);
const wf = (i, w = 0) => { const t = cues[i - 1].text.split(" "); const ws = t.map((x) => [...x].length + 1); const tot = ws.reduce((a, b) => a + b, 0); const bef = ws.slice(0, w).reduce((a, b) => a + b, 0); const a = cues[i - 1].start * FPS, b = cues[i - 1].end * FPS; return Math.round(a + ((b - a) * bef) / tot); };
const B = { hook: 0, hub: cf(3), fliki1: wf(5, 1), fliki2: cf(7), fliki3: cf(10), mj1: wf(12, 3), mj2: cf(17), bb1: wf(20, 1), bb2: cf(21), bb3: cf(24), ai: wf(25, 2), recap: wf(27, 3), cta: cf(30) };
const keys = Object.keys(B); const total = Math.round(cues.at(-1).end * FPS);
keys.forEach((k, i) => { const o = k === "hook" ? 0 : B[k] - 3; const e = i === keys.length - 1 ? total : B[keys[i + 1]] - 3; console.log(k.padEnd(7), "origin", o, "end", e, "len", e - o); });
