// Synthesizes a small, soft UI/motion-graphics SFX kit -> public/sfx/*.wav (44.1kHz mono 16-bit)
import fs from "node:fs";
const SR = 44100, TARGET_RMS = 0.1, PEAK = 0.89;
const N = (sec) => Math.floor(sec * SR);
let seed = 7; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647) * 2 - 1;
const lp = (x, fc) => { const a = Math.exp(-2 * Math.PI * fc / SR); let y = 0; return x.map((v) => (y = (1 - a) * v + a * y)); };
const hp = (x, fc) => { const l = lp(x, fc); return x.map((v, i) => v - l[i]); };
const env = (i, n, att, dec) => { const t = i / SR; return Math.min(1, t / att) * Math.exp(-t * dec); };
// tiny reverb: 3 short feedback combs, low mix, short tail
const reverb = (x, mix = 0.12) => {
  const out = x.slice(); for (const [d, g] of [[0.021, 0.35], [0.034, 0.3], [0.047, 0.25]]) {
    const dl = N(d); for (let i = dl; i < out.length; i++) out[i] += out[i - dl] * g * mix * 3; }
  return out;
};
const fadeEnd = (x, sec = 0.04) => { const f = N(sec); for (let i = 0; i < f; i++) x[x.length - 1 - i] *= i / f; return x; };
const kit = {};
kit.pop = () => { const n = N(0.22); let ph = 0; const x = new Array(n); for (let i = 0; i < n; i++) { const t = i / SR; const f = 180 + 420 * Math.exp(-t * 38); ph += 2 * Math.PI * f / SR; x[i] = (Math.sin(ph) + 0.18 * Math.sin(2 * ph)) * env(i, n, 0.004, 22); } return lp(x, 3800); };
kit.click = () => { const n = N(0.11); const nz = hp(Array.from({ length: n }, rnd), 1800); let ph = 0; const x = nz.map((v, i) => { ph += 2 * Math.PI * 1500 / SR; return (v * 0.7 + Math.sin(ph) * 0.35) * env(i, n, 0.0015, 70); }); return lp(x, 6500); };
const sweep = (sec, f0, f1, q) => { const n = N(sec); const x = new Array(n); let lo = 0, bp = 0; for (let i = 0; i < n; i++) { const p = i / n; const fc = f0 * Math.pow(f1 / f0, p); const f = 2 * Math.sin(Math.PI * fc / SR); const v = rnd(); lo += f * bp; const hi = v - lo - q * bp; bp += f * hi; x[i] = bp * Math.pow(Math.sin(Math.PI * p), 1.6); } return x; };
kit.whoosh = () => lp(sweep(0.7, 350, 2600, 0.45), 5200);
kit.swipe = () => lp(sweep(0.42, 900, 3600, 0.5), 5600);
const tone = (sec, parts, att, dec) => { const n = N(sec); return Array.from({ length: n }, (_, i) => { const t = i / SR; let v = 0; for (const [f, a, d] of parts) v += a * Math.sin(2 * Math.PI * f * t) * Math.exp(-t * d); return v * Math.min(1, t / att); }); };
kit.pluck = () => lp(tone(0.5, [[392, 1, 9], [784, 0.35, 14], [1176, 0.12, 20], [394, 0.4, 9]], 0.006), 4200);
kit.chime = () => lp(tone(0.55, [[659, 1, 7], [988, 0.45, 10], [1319, 0.18, 14], [661, 0.5, 7]], 0.008), 4600);
kit.thud = () => { const n = N(0.34); let ph = 0; const x = new Array(n); for (let i = 0; i < n; i++) { const t = i / SR; ph += 2 * Math.PI * (48 + 60 * Math.exp(-t * 18)) / SR; x[i] = Math.sin(ph) * env(i, n, 0.008, 11); } return lp(x, 400); };

fs.mkdirSync("public/sfx", { recursive: true });
console.log("name      dur(s)  peak   rms    clipped");
for (const [name, fn] of Object.entries(kit)) {
  let x = fadeEnd(reverb(fn()));
  const rms = Math.sqrt(x.reduce((s, v) => s + v * v, 0) / x.length), pk = Math.max(...x.map(Math.abs));
  const g = Math.min(TARGET_RMS / rms, PEAK / pk); x = x.map((v) => v * g);
  const pk2 = Math.max(...x.map(Math.abs)), rms2 = Math.sqrt(x.reduce((s, v) => s + v * v, 0) / x.length);
  const clipped = x.filter((v) => Math.abs(v) >= 0.999).length;
  const buf = Buffer.alloc(44 + x.length * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + x.length * 2, 4); buf.write("WAVEfmt ", 8); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34); buf.write("data", 36); buf.writeUInt32LE(x.length * 2, 40);
  x.forEach((v, i) => buf.writeInt16LE(Math.round(Math.max(-1, Math.min(1, v)) * 32767), 44 + i * 2));
  fs.writeFileSync(`public/sfx/${name}.wav`, buf);
  console.log(name.padEnd(9), (x.length / SR).toFixed(2).padStart(5), pk2.toFixed(2).padStart(6), rms2.toFixed(3).padStart(6), String(clipped).padStart(6));
}
