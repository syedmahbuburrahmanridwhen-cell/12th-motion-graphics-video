// subtitles.srt -> src/cues.generated.ts  (SRT is the single source of timing)
import fs from "node:fs";
const raw = fs.readFileSync(new URL("../subtitles.srt", import.meta.url), "utf8").replace(/\r/g, "");
const ts = (s) => { const m = s.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/); return +m[1]*3600 + +m[2]*60 + +m[3] + +m[4]/1000; };
const cues = raw.split(/\n\s*\n/).map((b) => b.trim()).filter(Boolean).map((b) => {
  const l = b.split("\n"); const [a, z] = l[1].split("-->");
  return { start: ts(a), end: ts(z), text: l.slice(2).join(" ").replace(/\s+/g, " ").trim() };
});
fs.writeFileSync(new URL("../src/cues.generated.ts", import.meta.url),
  `// AUTO-GENERATED from subtitles.srt by scripts/srt-to-cues.mjs\nexport type Cue = { start: number; end: number; text: string };\nexport const cues: Cue[] = ${JSON.stringify(cues, null, 2)};\n`);
console.log(cues.length, "cues, ends at", cues[cues.length-1].end);
