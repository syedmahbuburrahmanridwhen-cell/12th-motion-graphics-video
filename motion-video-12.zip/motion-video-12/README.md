# AI income tools — Remotion motion graphics (Graphite Gold, dark)

1. `npm install`
2. `npx remotion studio`  → preview (composition **Main**, 1920×1080, 30fps)
3. `npx remotion render src/index.ts Main out/video.mp4`

Optional: put the narration at `public/voiceover.mp3` → it plays in Studio (flag in `src/Main.tsx`).
To include it in a render: `REMOTION_INCLUDE_VO=1 npx remotion render src/index.ts Main out/video.mp4`.

Timing comes only from `subtitles.srt` → `npm run cues` regenerates `src/cues.generated.ts`.
SFX are synthesized (`npm run sfx`) into `public/sfx/`. Theme: `src/theme.ts`.
