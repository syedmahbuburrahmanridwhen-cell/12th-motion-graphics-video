import React from "react";
import { AbsoluteFill, Audio, Sequence, getRemotionEnvironment, staticFile, interpolate, continueRender, delayRender } from "remotion";
import { useEffect, useState } from "react";
import { BgMesh, Grade, Grain, Vignette, WipeAt } from "./components/layers";
import { SceneCtx, Sfx } from "./components/core";
import { theme } from "./theme";
import { TOTAL } from "./timing";
import { sceneOrder, originOf, endOf } from "./scenes";
import { S1Hook } from "./scenes/S1Hook";
import { S2Hub } from "./scenes/S2Hub";
import { S4aMidjourney, S4bMarkets } from "./scenes/S4Midjourney";
import { S6Balance, S7Recap, S8Cta } from "./scenes/S6Tail";
import { S5aBookIntro, S5bBookBuild, S5cAmazon } from "./scenes/S5BookBolt";
import { S3aFlikiIntro, S3bFlikiHow, S3cFlikiMoney } from "./scenes/S3Fliki";

// ---- Voiceover preview: put your narration at public/voiceover.mp3 ----
const PLAY_VOICEOVER_IN_STUDIO = true; // preview flag
const INCLUDE_VOICEOVER_IN_RENDER = false; // render flag (default off). Or set env REMOTION_INCLUDE_VO=1 when rendering.
const PreviewAudio: React.FC = () => {
  const env = getRemotionEnvironment();
  const wanted = env.isStudio ? PLAY_VOICEOVER_IN_STUDIO : INCLUDE_VOICEOVER_IN_RENDER || process.env.REMOTION_INCLUDE_VO === "1";
  const [ok, setOk] = useState(false);
  const [handle] = useState(() => (wanted ? delayRender("voiceover check") : null));
  useEffect(() => {
    if (!wanted || handle === null) return;
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => setOk(r.ok && (r.headers.get("content-type") ?? "").includes("audio")))
      .catch(() => setOk(false))
      .finally(() => continueRender(handle));
  }, [wanted, handle]);
  return wanted && ok ? <Audio src={staticFile("voiceover.mp3")} volume={1} /> : null;
};

const scenes: Record<(typeof sceneOrder)[number], React.FC> = {
  hook: S1Hook, hub: S2Hub, fliki1: S3aFlikiIntro, fliki2: S3bFlikiHow, fliki3: S3cFlikiMoney, mj1: S4aMidjourney, mj2: S4bMarkets, bb1: S5aBookIntro, bb2: S5bBookBuild, bb3: S5cAmazon, ai: S6Balance, recap: S7Recap, cta: S8Cta,
} as never;

export const Main: React.FC = () => {
  const cuts = sceneOrder.slice(1).map((k) => originOf(k));
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <BgMesh />
      {sceneOrder.map((k) => {
        const C = scenes[k];
        if (!C) return null;
        return (
          <Sequence key={k} from={originOf(k)} durationInFrames={endOf(k) - originOf(k)}>
            <SceneCtx.Provider value={{ origin: originOf(k) }}><C /></SceneCtx.Provider>
          </Sequence>
        );
      })}
      <Grade />
      {cuts.map((c) => <WipeAt key={c} cut={c} />)}
      {cuts.map((c) => <Sfx key={c} at={c - 8} name="swipe" vol={0.22} />)}
      <Grain />
      <Vignette />
      <PreviewAudio />
    </AbsoluteFill>
  );
};
