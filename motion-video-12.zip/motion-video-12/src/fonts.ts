// Offline fonts: bundled Hind Siliguri woff2 (bengali + latin subsets), loaded via FontFace.
import { continueRender, delayRender, staticFile } from "remotion";

const BN = "U+0951-0952,U+0964-0965,U+0980-09FE,U+1CD0,U+1CD2,U+1CD5-1CD6,U+1CD8,U+1CE1,U+1CEA,U+1CED,U+1CF2,U+1CF5-1CF7,U+200C-200D,U+20B9,U+25CC,U+A8F1";
const LT = "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD";
const faces: [string, string, string][] = [
  ["bengali", "500", BN], ["bengali", "700", BN], ["latin", "500", LT], ["latin", "700", LT],
];
const handle = delayRender("fonts");
Promise.all(
  faces.map(async ([sub, weight, range]) => {
    const f = new FontFace("Hind Siliguri", `url(${staticFile(`fonts/hind-siliguri-${sub}-${weight}-normal.woff2`)})`, { weight, unicodeRange: range } as FontFaceDescriptors);
    await f.load();
    document.fonts.add(f);
  }),
).then(() => continueRender(handle)).catch((e) => { console.error(e); continueRender(handle); });
