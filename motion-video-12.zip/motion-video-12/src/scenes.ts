// Scene boundaries come from the SRT. `cut` = frame where the wipe hides the swap (6 frames before the spoken boundary).
import { cueFrame, wordFrame, TOTAL } from "./timing";
const CUT_LEAD = 3;
export const boundaries = {
  hook: 0,
  hub: cueFrame(3),
  fliki1: wordFrame(5, 1), // "Number one"
  fliki2: cueFrame(7),
  fliki3: cueFrame(10),
  mj1: wordFrame(12, 3), // "Number two"
  mj2: cueFrame(17),
  bb1: wordFrame(20, 1), // "Number three"
  bb2: cueFrame(21),
  bb3: cueFrame(24),
  ai: wordFrame(25, 2), // "বর্তমানে AI-র যুগে"
  recap: wordFrame(27, 3), // "দেরি না করে আজই"
  cta: cueFrame(30),
};
export const sceneOrder = Object.keys(boundaries) as (keyof typeof boundaries)[];
export const originOf = (k: keyof typeof boundaries) => (k === "hook" ? 0 : boundaries[k] - CUT_LEAD);
export const endOf = (k: keyof typeof boundaries) => {
  const i = sceneOrder.indexOf(k);
  return i === sceneOrder.length - 1 ? TOTAL : originOf(sceneOrder[i + 1]);
};
