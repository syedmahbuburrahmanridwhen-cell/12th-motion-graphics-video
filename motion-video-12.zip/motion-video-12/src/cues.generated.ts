// AUTO-GENERATED from subtitles.srt by scripts/srt-to-cues.mjs
export type Cue = { start: number; end: number; text: string };
export const cues: Cue[] = [
  {
    "start": 0.08,
    "end": 2.22,
    "text": "কোন skill নেই বলে টাকা কামাতে পারছেন"
  },
  {
    "start": 2.22,
    "end": 4.86,
    "text": "না? এই তিনটি powerful AI tool"
  },
  {
    "start": 4.86,
    "end": 7.5,
    "text": "আপনার হয়ে একাই সব কঠিন কাজ করে দেবে।"
  },
  {
    "start": 7.5,
    "end": 10.26,
    "text": "কোন অভিজ্ঞতা ছাড়াই just copy paste করে"
  },
  {
    "start": 10.26,
    "end": 14.34,
    "text": "income। Number one, Fliki.ai। Faceless"
  },
  {
    "start": 14.34,
    "end": 16.2,
    "text": "YouTube channel চালাতে চান? শুধু"
  },
  {
    "start": 16.2,
    "end": 18.44,
    "text": "একটা topic লিখে দিন। এই tool নিজেই"
  },
  {
    "start": 18.44,
    "end": 20.22,
    "text": "video's script লিখবে, professional"
  },
  {
    "start": 20.22,
    "end": 22.48,
    "text": "voiceover দেবে এবং আকর্ষণীয় video"
  },
  {
    "start": 22.48,
    "end": 24.46,
    "text": "বানিয়ে দেবে। আপনার কাজ শুধু সেটা"
  },
  {
    "start": 24.46,
    "end": 26.8,
    "text": "YouTube-e upload করা আর monetization-er"
  },
  {
    "start": 26.8,
    "end": 29.32,
    "text": "মাধ্যমে টাকা কামানো। Number two,"
  },
  {
    "start": 29.32,
    "end": 31.6,
    "text": "Midjourney। এখানে শুধু একটা prompt"
  },
  {
    "start": 31.6,
    "end": 34.2,
    "text": "লিখে দিন, যেমন একটি সুন্দর পাখির"
  },
  {
    "start": 34.2,
    "end": 37.26,
    "text": "নান্দনিক ছবি। AI সাথে সাথে চমৎকার সব"
  },
  {
    "start": 37.26,
    "end": 39.48,
    "text": "ছবি generate করে দেবে। সেই ছবিগুলো"
  },
  {
    "start": 39.48,
    "end": 41.34,
    "text": "Shutterstock বা Freepik-e sell করে"
  },
  {
    "start": 41.34,
    "end": 43.12,
    "text": "dollar আয় করুন। আলাদা করে কোন"
  },
  {
    "start": 43.12,
    "end": 45.02,
    "text": "graphics design-er কাজ শেখার প্রয়োজনই"
  },
  {
    "start": 45.02,
    "end": 47.82,
    "text": "নেই। Number three, Book Bolt। Tool-tike"
  },
  {
    "start": 47.82,
    "end": 50.26,
    "text": "শুধু বলুন বাচ্চাদের জন্য একটি শিক্ষণীয়"
  },
  {
    "start": 50.26,
    "end": 53.22,
    "text": "গল্প লিখে দিতে। এটি চোখের পলকে চমৎকার"
  },
  {
    "start": 53.22,
    "end": 56.36,
    "text": "গল্প এবং ছবি সহ পুরো বই তৈরি করে দেবে।"
  },
  {
    "start": 56.36,
    "end": 57.98,
    "text": "সেটি Amazon-e publish করলেই"
  },
  {
    "start": 57.98,
    "end": 60.82,
    "text": "passive income। বর্তমানে AI-er যুগে"
  },
  {
    "start": 60.82,
    "end": 63.46,
    "text": "সফল হতে গেলে প্রথাগত skill-er চেয়ে AI"
  },
  {
    "start": 63.46,
    "end": 66.36,
    "text": "ব্যবহারের বুদ্ধিটাই আসল। দেরি না করে আজই"
  },
  {
    "start": 66.36,
    "end": 68.46,
    "text": "শুরু করুন। আর এই দরকারি video-ti"
  },
  {
    "start": 68.46,
    "end": 70.88,
    "text": "হারিয়ে যাওয়ার আগে এখনই save করে রাখুন।"
  },
  {
    "start": 70.88,
    "end": 72.84,
    "text": "আর যারা নিজেদের personal brand বা"
  },
  {
    "start": 72.84,
    "end": 74.72,
    "text": "business-er জন্য professional website"
  },
  {
    "start": 74.72,
    "end": 76.92,
    "text": "বানাতে চান, তারা চাইলে আমাকে inbox"
  },
  {
    "start": 76.92,
    "end": 78.4,
    "text": "করতে পারেন। ধন্যবাদ।"
  }
];
