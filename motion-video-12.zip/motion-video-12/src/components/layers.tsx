import React from "react";
import { AbsoluteFill, Sequence, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { W, H } from "../timing";

export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 80) * 90, d2 = Math.cos(frame / 95) * 70, d3 = Math.sin(frame / 120) * 50;
  return (
    <AbsoluteFill style={{ background: `radial-gradient(ellipse at 50% 40%, ${theme.colors.bgAlt}, ${theme.colors.bg} 70%)` }}>
      <div style={{ position: "absolute", width: 1300, height: 1300, borderRadius: "50%", top: -620 + d3, left: -380 + d1, background: `radial-gradient(circle, ${theme.colors.primary}26, transparent 62%)` }} />
      <div style={{ position: "absolute", width: 1100, height: 1100, borderRadius: "50%", bottom: -560 - d3, right: -300 - d2, background: `radial-gradient(circle, ${theme.colors.accent}1c, transparent 64%)` }} />
      <div style={{ position: "absolute", inset: 0, opacity: 0.5, backgroundImage: `radial-gradient(${theme.colors.border} 1.4px, transparent 1.6px)`, backgroundSize: "64px 64px", backgroundPosition: `${-frame * 0.3}px ${-frame * 0.2}px`, WebkitMaskImage: "radial-gradient(ellipse at center, black 30%, transparent 78%)" }} />
      {Array.from({ length: 16 }).map((_, i) => {
        const x = (i * 337) % W, sp = 0.25 + (i % 5) * 0.12, y = (H + 80 - ((frame * sp + i * 211) % (H + 160)));
        return <div key={i} style={{ position: "absolute", left: x, top: y, width: 5 + (i % 3) * 2, height: 5 + (i % 3) * 2, borderRadius: 10, background: i % 4 === 0 ? theme.colors.accent : theme.colors.primary, opacity: 0.1 + (i % 4) * 0.05 }} />;
      })}
    </AbsoluteFill>
  );
};

export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.primary, mixBlendMode: "soft-light", opacity: 0.14 }} />
    <AbsoluteFill style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.12), transparent 26%, transparent 74%, rgba(0,0,0,0.22))" }} />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return <AbsoluteFill style={{ pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px", backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`, opacity: 0.06, mixBlendMode: "overlay" }} />;
};

export const Vignette: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 54%, rgba(0,0,0,0.38) 100%)" }} />
);

/** Scene-cut wipe: dark panel with a gold leading edge; the scene swap happens while it fully covers the frame (local frame 8 of 16). */
export const WipeAt: React.FC<{ cut: number }> = ({ cut }) => (
  <Sequence from={cut - 8} durationInFrames={16}><WipePanel /></Sequence>
);
const WipePanel: React.FC = () => {
  const f = useCurrentFrame();
  const Wp = 2600;
  const p = interpolate(f, [0, 16], [0, 1], { easing: theme.ease.wipe, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const left = interpolate(p, [0, 0.5, 1], [-Wp - 140, (W - Wp) / 2, W + 140]);
  return (
    <AbsoluteFill style={{ pointerEvents: "none", overflow: "hidden" }}>
      <div style={{ position: "absolute", top: -200, height: H + 400, width: Wp, left, transform: "skewX(-12deg)", background: `linear-gradient(90deg, ${theme.colors.bg}, ${theme.colors.bgAlt} 70%, ${theme.colors.surface})`, boxShadow: `inset -10px 0 0 ${theme.colors.primary}, 40px 0 90px ${theme.colors.glowSoft}` }}>
        <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 4, background: theme.colors.accent, opacity: 0.8 }} />
      </div>
    </AbsoluteFill>
  );
};
