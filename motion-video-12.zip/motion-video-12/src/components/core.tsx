import React, { createContext, useContext } from "react";
import { Audio, Img, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { theme, gold } from "../theme";
import { VIS_LEAD, wordFrame } from "../timing";
import { logos, LogoKey } from "../assets";

// ---------- scene context & helpers ----------
export const SceneCtx = createContext({ origin: 0 });
/** at(cue, word, lead) -> local frame (inside the current scene) at which something tied to that spoken word should land. */
export const useAt = () => {
  const { origin } = useContext(SceneCtx);
  return (cue: number, word = 0, lead = VIS_LEAD) => wordFrame(cue, word) - lead - origin;
};
const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
export const ramp = (f: number, a: number, b: number, to: [number, number] = [0, 1], easing: (t: number) => number = theme.ease.out) =>
  interpolate(f, [a, b], to, { easing, ...clamp });

// ---------- SFX ----------
export const Sfx: React.FC<{ at: number; name: "pop" | "click" | "whoosh" | "swipe" | "pluck" | "chime" | "thud"; vol?: number; rate?: number }> = ({ at, name, vol = 0.3, rate = 1 }) => (
  <Sequence from={Math.max(0, Math.round(at) - 3)} layout="none">
    <Audio src={staticFile(`sfx/${name}.wav`)} volume={vol} playbackRate={rate} />
  </Sequence>
);

// ---------- entrance wrapper (opacity + translate + scale, spring; optional fast exit) ----------
export const Pop: React.FC<{
  at: number; from?: { x?: number; y?: number; s?: number; r?: number }; preset?: keyof typeof theme.spring;
  out?: number; style?: React.CSSProperties; children?: React.ReactNode;
}> = ({ at, from, preset = "smooth", out, style, children }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - at, fps, config: theme.spring[preset] });
  const ex = out === undefined ? 0 : interpolate(frame, [out, out + 8], [0, 1], { easing: theme.ease.in, ...clamp });
  const f = { x: 0, y: 40, s: 0.94, r: 0, ...from };
  const o = Math.min(1, Math.max(0, p * 1.4)) * (1 - ex);
  const sc = (f.s + (1 - f.s) * p) * (1 - ex * 0.05);
  return (
    <div style={{ opacity: o, transform: `translate(${f.x * (1 - p)}px, ${f.y * (1 - p) - ex * 26}px) scale(${sc}) rotate(${f.r * (1 - p)}deg)`, ...style }}>{children}</div>
  );
};

// ---------- word-by-word text (Bengali-safe: split only on spaces, never letters) ----------
export const Words: React.FC<{
  text: string; at: number; per?: number; size: number; color?: string; hi?: number[]; align?: "left" | "center" | "right";
  weight?: number; out?: number; glow?: boolean; style?: React.CSSProperties; maxWidth?: number; dim?: number[]; times?: number[];
}> = ({ text, at, per = theme.motion.wordStagger, size, color = theme.colors.text, hi = [], align = "center", weight = 700, out, glow, style, maxWidth, dim = [], times }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const ex = out === undefined ? 0 : interpolate(frame, [out, out + 9], [0, 1], { easing: theme.ease.in, ...clamp });
  return (
    <div style={{
      display: "flex", flexWrap: "wrap", columnGap: Math.round(size * 0.27), rowGap: Math.round(size * 0.04), maxWidth,
      justifyContent: align === "center" ? "center" : align === "right" ? "flex-end" : "flex-start",
      fontFamily: theme.fonts.display, fontWeight: weight, fontSize: size, lineHeight: 1.32, letterSpacing: 0, color, ...style,
    }}>
      {text.split(" ").map((w, i) => {
        const p = spring({ frame: frame - (times ? times[i] : at + i * per), fps, config: theme.spring.snappy });
        const isHi = hi.includes(i);
        const wordEx = Math.min(1, Math.max(0, ex * 1.2 - i * 0.02));
        return (
          <span key={i} style={{
            display: "inline-block", whiteSpace: "nowrap", opacity: Math.min(1, Math.max(0, p * 1.4)) * (1 - wordEx) * (dim.includes(i) ? 0.55 : 1),
            transform: `translateY(${(1 - p) * size * 0.32 - wordEx * size * 0.2}px) scale(${0.9 + 0.1 * p})`,
            ...(isHi ? { backgroundImage: gold, WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent", filter: glow ? `drop-shadow(0 0 ${size * 0.28}px ${theme.colors.glow})` : undefined } : {}),
          }}>{w}</span>
        );
      })}
    </div>
  );
};

// ---------- surfaces ----------
export const Glass: React.FC<{ style?: React.CSSProperties; radius?: number; children?: React.ReactNode }> = ({ style, radius = theme.radius.md, children }) => (
  <div style={{
    background: "linear-gradient(160deg, rgba(41,41,47,0.94), rgba(24,24,27,0.94))", border: `1px solid ${theme.colors.border}`,
    borderRadius: radius, boxShadow: theme.shadow.card, position: "relative", overflow: "hidden", ...style,
  }}>
    <div style={{ position: "absolute", inset: 0, borderRadius: radius, background: "linear-gradient(180deg, rgba(250,246,236,0.06), transparent 22%)", pointerEvents: "none" }} />
    {children}
  </div>
);

export const Window: React.FC<{ style?: React.CSSProperties; title?: string; children?: React.ReactNode }> = ({ style, title, children }) => (
  <Glass style={style} radius={theme.radius.md}>
    <div style={{ height: 58, display: "flex", alignItems: "center", padding: "0 24px", gap: 10, borderBottom: `1px solid ${theme.colors.border}` }}>
      {[0, 1, 2].map((i) => <div key={i} style={{ width: 13, height: 13, borderRadius: 13, background: i === 0 ? theme.colors.accent : theme.colors.textDim, opacity: i === 0 ? 1 : 0.4 }} />)}
      {title && <div style={{ marginLeft: 16, fontFamily: theme.fonts.body, fontWeight: 500, fontSize: 24, color: theme.colors.textDim }}>{title}</div>}
    </div>
    <div style={{ position: "relative", height: `calc(100% - 58px)` }}>{children}</div>
  </Glass>
);

export const LogoCard: React.FC<{ logo: LogoKey; h: number; radius?: number; style?: React.CSSProperties; glow?: boolean }> = ({ logo, h, radius = 28, style, glow }) => {
  const l = logos[logo];
  return (
    <div style={{
      width: Math.round((h * l.w) / l.h), height: h, borderRadius: radius, overflow: "hidden", flexShrink: 0,
      boxShadow: glow ? `0 0 0 2px ${theme.colors.primary}, 0 0 70px ${theme.colors.glow}, 0 30px 60px -20px rgba(0,0,0,0.7)` : "0 30px 60px -22px rgba(0,0,0,0.75), 0 0 0 1px rgba(250,246,236,0.08)", ...style,
    }}>
      <Img src={staticFile(l.src)} style={{ width: "100%", height: "100%", display: "block" }} />
    </div>
  );
};

// ---------- icons (theme-colored SVG, no emoji) ----------
const P: Record<string, string> = {
  doc: "M7 3h7l4 4v14H7z M14 3v4h4 M9.5 12h6 M9.5 15.5h6 M9.5 8.5h2",
  image: "M4 5h16v14H4z M4 17l5-5 4 4 3-3 4 4",
  book: "M5 4h10a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z M5 17a3 3 0 0 1 3-3h10",
  upload: "M12 16V5 M7.5 9.5L12 5l4.5 4.5 M5 19h14",
  check: "M5 12.5l4.5 4.5L19 7.5",
  bookmark: "M7 4h10v17l-5-4-5 4z",
  mail: "M4 6h16v12H4z M4 7l8 6 8-6",
  bolt: "M13 3L5 13.5h6L10 21l8-10.5h-6z",
  pen: "M4 20l1.2-4.6L16 4.6a2 2 0 0 1 2.8 0l.6.6a2 2 0 0 1 0 2.8L8.6 18.8z M14.5 6.2l3.3 3.3",
  spark: "M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z",
  mic: "M12 14a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v5a3 3 0 0 0 3 3z M6 11a6 6 0 0 0 12 0 M12 17v3",
  cross: "M6 6l12 12 M18 6L6 18",
  video: "M3.5 6h12a1.5 1.5 0 0 1 1.5 1.5v9a1.5 1.5 0 0 1-1.5 1.5h-12A1.5 1.5 0 0 1 2 16.5v-9A1.5 1.5 0 0 1 3.5 6z M17 10l5-3v10l-5-3",
  globe: "M12 3a9 9 0 1 0 0.01 0z M3 12h18 M12 3c3 3 3 15 0 18 M12 3c-3 3-3 15 0 18",
  arrow: "M4 12h15 M13 6l6 6-6 6",
};
export const Icon: React.FC<{ name: keyof typeof P | "play" | "cursor"; size: number; color?: string; stroke?: number; style?: React.CSSProperties }> = ({ name, size, color = theme.colors.primary, stroke = 1.8, style }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" style={style} fill={name === "play" || name === "cursor" ? color : "none"} stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    {name === "play" ? <path d="M8 5.5v13l11-6.5z" /> : name === "cursor" ? <path d="M5 3l14 7-6 2-2 6z" stroke={theme.colors.ink} strokeWidth={1} /> : <path d={P[name]} />}
  </svg>
);

export const Coin: React.FC<{ size: number; spin?: number; style?: React.CSSProperties }> = ({ size, spin = 0, style }) => {
  const frame = useCurrentFrame();
  const sx = spin ? Math.abs(Math.cos((frame * spin) / 30 * Math.PI)) * 0.85 + 0.15 : 1;
  return (
    <div style={{ width: size, height: size, borderRadius: size, background: gold, border: `${size * 0.06}px solid #FFE3A0`, boxShadow: `inset 0 -${size * 0.08}px ${size * 0.12}px rgba(150,90,0,0.45), 0 0 ${size * 0.5}px ${theme.colors.glowSoft}`, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: size * 0.56, color: theme.colors.ink, transform: `scaleX(${sx})`, ...style }}>$</div>
  );
};

/** Deterministic coin burst from (cx, cy) starting at local frame `at`. */
export const CoinBurst: React.FC<{ at: number; cx: number; cy: number; count?: number; power?: number }> = ({ at, cx, cy, count = 14, power = 1 }) => {
  const frame = useCurrentFrame();
  const t = frame - at;
  if (t < 0 || t > 60) return null;
  return (
    <>
      {Array.from({ length: count }).map((_, i) => {
        const a = ((i * 137.5) % 360) * (Math.PI / 180) - Math.PI / 2 + Math.sin(i * 3.1) * 0.5;
        const v = (7 + ((i * 53) % 9)) * power;
        const x = cx + Math.cos(a) * v * t * 0.9;
        const y = cy + Math.sin(a) * v * t * 0.9 + 0.5 * 0.55 * t * t * 0.5;
        const s = 26 + ((i * 17) % 22);
        return <div key={i} style={{ position: "absolute", left: x - s / 2, top: y - s / 2, opacity: interpolate(t, [0, 6, 40, 60], [0, 1, 1, 0], clamp) }}><Coin size={s} spin={1.5 + (i % 3) * 0.4} /></div>;
      })}
    </>
  );
};

/** Word-timed typewriter: each word pops in when its frame arrives; caret blinks at the end. */
export const TypedWords: React.FC<{ words: { text: string; at: number }[]; size: number; color?: string; style?: React.CSSProperties }> = ({ words, size, color = theme.colors.text, style }) => {
  const frame = useCurrentFrame();
  const shown = words.filter((w) => frame >= w.at);
  return (
    <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", columnGap: size * 0.26, rowGap: 4, fontFamily: theme.fonts.body, fontWeight: 500, fontSize: size, lineHeight: 1.4, color, ...style }}>
      {shown.map((w, i) => {
        const p = ramp(frame, w.at, w.at + 7);
        return <span key={i} style={{ opacity: p, transform: `translateY(${(1 - p) * 10}px)`, display: "inline-block", whiteSpace: "nowrap" }}>{w.text}</span>;
      })}
      <span style={{ width: 4, height: size * 1.05, background: theme.colors.primary, opacity: Math.floor(frame / 14) % 2 === 0 ? 1 : 0.15, borderRadius: 2 }} />
    </div>
  );
};
