import React from "react";
import { useCurrentFrame } from "remotion";
import { theme, gold } from "../theme";
import { Icon, Pop, ramp } from "./core";

/** "01 /03" carousel-style counter with a 3-pill rail. */
export const NumberBadge: React.FC<{ n: 1 | 2 | 3; at: number; size?: number; style?: React.CSSProperties }> = ({ n, at, size = 210, style }) => {
  const f = useCurrentFrame();
  return (
    <Pop at={at} from={{ y: 50, s: 0.8 }} preset="bouncy" style={style}>
      <div style={{ display: "flex", alignItems: "baseline", gap: 18, fontFamily: theme.fonts.display, fontWeight: 700, lineHeight: 1 }}>
        <span style={{ fontSize: size, backgroundImage: gold, WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent", fontVariantNumeric: "tabular-nums", paddingBottom: size * 0.08 }}>{`0${n}`}</span>
        <span style={{ fontSize: size * 0.27, color: theme.colors.textDim, fontVariantNumeric: "tabular-nums" }}>/03</span>
      </div>
      <div style={{ display: "flex", gap: 12, marginTop: 6 }}>
        {[1, 2, 3].map((i) => (
          <div key={i} style={{ height: 10, borderRadius: 10, width: i === n ? 10 + 110 * ramp(f, at + 6, at + 26) : 40, background: i === n ? theme.colors.primary : theme.colors.surfaceHi }} />
        ))}
      </div>
    </Pop>
  );
};

export const Keycap: React.FC<{ label: string; w: number; pressAt?: number; at: number; size?: number }> = ({ label, w, pressAt, at, size = 58 }) => {
  const f = useCurrentFrame();
  const press = pressAt === undefined ? 0 : ramp(f, pressAt, pressAt + 3, [0, 1], theme.ease.out) * (1 - ramp(f, pressAt + 9, pressAt + 16, [0, 1], theme.ease.out));
  const lit = pressAt !== undefined && label.length === 1;
  return (
    <Pop at={at} from={{ y: 60, s: 0.8 }} preset="bouncy">
      <div style={{ width: w, height: 150, borderRadius: 30, paddingBottom: 12 - press * 8, transform: `translateY(${press * 8}px)`,
        background: lit && press > 0.05 ? theme.colors.primary : theme.colors.surfaceHi, boxShadow: `0 ${12 - press * 8}px 0 #0a0a0b, 0 22px 40px -12px rgba(0,0,0,0.7)${press > 0.05 && lit ? `, 0 0 60px ${theme.colors.glow}` : ""}`, border: `1px solid ${theme.colors.border}`,
        display: "flex", alignItems: "center", justifyContent: "center", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: size, color: lit && press > 0.05 ? theme.colors.ink : theme.colors.text }}>
        {label}
      </div>
    </Pop>
  );
};

export const Chip: React.FC<{ at: number; icon?: React.ComponentProps<typeof Icon>["name"]; text: string; size?: number; hot?: boolean; style?: React.CSSProperties }> = ({ at, icon, text, size = 40, hot, style }) => (
  <Pop at={at} from={{ y: 30, s: 0.85 }} preset="snappy" style={style}>
    <div style={{ display: "inline-flex", alignItems: "center", gap: 14, padding: `${size * 0.32}px ${size * 0.62}px`, borderRadius: 999, fontFamily: theme.fonts.body, fontWeight: 700, fontSize: size,
      background: hot ? theme.colors.primary : theme.colors.surface, color: hot ? theme.colors.ink : theme.colors.text, border: `1px solid ${hot ? "transparent" : theme.colors.border}`, boxShadow: hot ? `0 0 50px ${theme.colors.glowSoft}` : theme.shadow.pop, lineHeight: 1.3 }}>
      {icon && <Icon name={icon} size={size * 0.95} color={hot ? theme.colors.ink : theme.colors.primary} />}
      {text}
    </div>
  </Pop>
);

/** Fades/lifts an absolutely-positioned group out starting at local frame `at` (exits are faster than entrances). */
export const Exit: React.FC<{ at: number; children?: React.ReactNode }> = ({ at, children }) => {
  const f = useCurrentFrame();
  const p = ramp(f, at, at + 9, [0, 1], theme.ease.in);
  return <div style={{ position: "absolute", inset: 0, opacity: 1 - p, transform: `translateY(${-30 * p}px) scale(${1 - 0.04 * p})` }}>{children}</div>;
};
