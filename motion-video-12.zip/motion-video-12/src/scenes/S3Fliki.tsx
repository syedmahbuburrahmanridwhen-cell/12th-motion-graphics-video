import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Coin, CoinBurst, Glass, Icon, LogoCard, Pop, Sfx, Window, Words, ramp, useAt } from "../components/core";
import { Chip, Exit, NumberBadge } from "../components/parts";

/** 01 — intro card */
export const S3aFlikiIntro: React.FC = () => {
  const f = useCurrentFrame();
  const at = useAt();
  const logoAt = at(5, 3);
  const tilt = Math.sin(f / 40) * 3;
  return (
    <AbsoluteFill>
      <Sfx at={at(5, 1)} name="whoosh" vol={0.26} />
      <Sfx at={logoAt} name="pluck" vol={0.3} />
      <Sfx at={at(6, 0)} name="pop" vol={0.28} />
      <div style={{ position: "absolute", left: 1000, top: 140, width: 820, height: 820, borderRadius: 820, background: `radial-gradient(circle, ${theme.colors.glowSoft}, transparent 66%)`, transform: `scale(${1 + Math.sin(f / 30) * 0.04})` }} />
      <NumberBadge n={1} at={at(5, 1)} style={{ position: "absolute", left: 130, top: 90 }} />
      <Words text="Fliki.ai" at={0} times={[at(5, 3)]} size={210} align="left" style={{ position: "absolute", left: 130, top: 400 }} />
      <div style={{ position: "absolute", left: 130, top: 690, display: "flex", alignItems: "center", gap: 28 }}>
        <Words text="Faceless" at={0} times={[at(5, 4)]} size={70} align="left" color={theme.colors.textDim} />
        <Pop at={at(6, 0)} from={{ x: -30, s: 0.7 }} preset="bouncy"><LogoCard logo="youtube" h={92} radius={22} /></Pop>
        <Words text="channel" at={0} times={[at(6, 1)]} size={70} align="left" color={theme.colors.textDim} />
      </div>
      <Pop at={logoAt} from={{ x: 120, s: 0.6, r: 8 }} preset="bouncy" style={{ position: "absolute", left: 1010, top: 340 + Math.sin(f / 28) * 9 }}>
        <div style={{ transform: `perspective(1800px) rotateY(${-11 + tilt}deg) rotateX(3deg)` }}><LogoCard logo="fliki" h={420} radius={40} glow /></div>
      </Pop>
      {[0, 1, 2, 3].map((i) => (
        <Pop key={i} at={logoAt + 8 + i * 4} from={{ s: 0.2, r: 90 }} preset="bouncy" style={{ position: "absolute", left: [960, 1760, 1700, 1020][i], top: [290, 250, 800, 820][i] + Math.sin(f / 20 + i) * 8 }}>
          <Icon name="spark" size={[56, 44, 64, 40][i]} color={i % 2 ? theme.colors.accent : theme.colors.primary} />
        </Pop>
      ))}
    </AbsoluteFill>
  );
};

const wave = (f: number, i: number) => 0.25 + 0.75 * Math.abs(Math.sin(f / 5 + i * 0.7) * Math.cos(f / 11 + i * 0.3));

/** topic -> script / voiceover / video */
export const S3bFlikiHow: React.FC = () => {
  const f = useCurrentFrame();
  const at = useAt();
  const typeA = at(7, 0), typeB = at(7, 1);
  const btn = at(7, 5, 2);
  const press = ramp(f, btn, btn + 3) * (1 - ramp(f, btn + 8, btn + 14));
  const cards = [
    { at: at(8, 0), icon: "doc", title: "Script" },
    { at: at(9, 0), icon: "mic", title: "Voiceover" },
    { at: at(9, 3), icon: "video", title: "Video" },
  ] as const;
  const cur = ramp(f, btn - 22, btn - 2, [0, 1], theme.ease.inOut);
  return (
    <AbsoluteFill>
      <Sfx at={at(7, 0, 8)} name="pop" vol={0.28} />
      <Sfx at={btn} name="click" vol={0.3} />
      <Sfx at={cards[0].at} name="pop" vol={0.28} />
      <Sfx at={cards[2].at} name="chime" vol={0.28} />
      <Pop at={0} from={{ y: -20 }} style={{ position: "absolute", left: 120, top: 60, display: "flex", alignItems: "center", gap: 20 }}>
        <LogoCard logo="fliki" h={70} radius={16} />
        <div style={{ fontFamily: theme.fonts.body, fontWeight: 700, fontSize: 46, color: theme.colors.textDim }}>Fliki.ai</div>
      </Pop>
      <Pop at={at(7, 0, 14)} from={{ x: -60 }} style={{ position: "absolute", left: 120, top: 190, width: 800, height: 700 }}>
        <Window style={{ width: 800, height: 700 }} title="Create video">
          <div style={{ padding: "40px 48px", display: "flex", flexDirection: "column", gap: 24 }}>
            <div style={{ fontFamily: theme.fonts.body, fontWeight: 700, fontSize: 36, color: theme.colors.textDim }}>Topic</div>
            <div style={{ height: 150, borderRadius: 26, background: theme.colors.bg, border: `2px solid ${theme.colors.primary}55`, padding: "30px 34px", boxShadow: `0 0 50px ${theme.colors.glowSoft}` }}>
              <div style={{ fontFamily: theme.fonts.body, fontWeight: 500, fontSize: 54, display: "flex", alignItems: "center", gap: 16, color: theme.colors.text, lineHeight: 1.3 }}>
                {f >= typeA && <span style={{ opacity: ramp(f, typeA, typeA + 6) }}>আপনার</span>}
                {f >= typeB && <span style={{ opacity: ramp(f, typeB, typeB + 6) }}>topic</span>}
                <span style={{ width: 4, height: 56, background: theme.colors.primary, opacity: Math.floor(f / 14) % 2 === 0 ? 1 : 0.15 }} />
              </div>
            </div>
            <div style={{ marginTop: 18, display: "flex", alignItems: "center", gap: 20 }}>
              <div style={{ height: 120, borderRadius: 60, padding: "0 56px", display: "flex", alignItems: "center", gap: 18, background: theme.colors.primary, color: theme.colors.ink, fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 52, transform: `scale(${1 - press * 0.06})`, boxShadow: `0 0 ${50 + press * 40}px ${theme.colors.glow}` }}>
                <Icon name="bolt" size={52} color={theme.colors.ink} stroke={2.4} /> Generate
              </div>
            </div>
            <div style={{ display: "flex", gap: 16, marginTop: 34 }}>
              {[190, 150, 220].map((w, k) => <div key={k} style={{ width: w, height: 46, borderRadius: 23, background: theme.colors.bg, border: `1px solid ${theme.colors.border}`, opacity: ramp(f, at(7, 0, 4) + k * 5, at(7, 0, 4) + k * 5 + 10) }} />)}
            </div>
          </div>
          <div style={{ position: "absolute", left: 420 + (1 - cur) * 120, top: 360 + (1 - cur) * 120, opacity: cur }}><Icon name="cursor" size={66} color={theme.colors.text} /></div>
        </Window>
      </Pop>
      {cards.map((c, i) => {
        const top = 190 + i * 245;
        const p = ramp(f, c.at + 10, c.at + 30);
        return (
          <React.Fragment key={i}>
            <svg width={120} height={20} style={{ position: "absolute", left: 925, top: top + 100 }}>
              <line x1={0} y1={10} x2={120 * ramp(f, c.at - 6, c.at + 6)} y2={10} stroke={theme.colors.primary} strokeWidth={4} strokeDasharray="10 10" strokeDashoffset={-f * 1.2} strokeLinecap="round" />
            </svg>
            <Pop at={c.at} from={{ x: 80, s: 0.9 }} preset="snappy" style={{ position: "absolute", left: 1050, top }}>
              <Glass style={{ width: 750, height: 215 }} radius={36}>
                <div style={{ display: "flex", height: "100%", alignItems: "center", gap: 34, padding: "0 40px" }}>
                  <div style={{ width: 120, height: 120, borderRadius: 32, background: theme.colors.bg, border: `1px solid ${theme.colors.border}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Icon name={c.icon} size={70} /></div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 56, color: theme.colors.text, lineHeight: 1.2 }}>{c.title}</div>
                    {i === 0 && [0.92, 0.7, 0.8].map((w, k) => <div key={k} style={{ height: 12, borderRadius: 8, marginTop: 14, width: `${w * 100 * ramp(f, c.at + 8 + k * 5, c.at + 24 + k * 5)}%`, background: theme.colors.surfaceHi }} />)}
                    {i === 1 && <div style={{ display: "flex", alignItems: "center", gap: 6, height: 54, marginTop: 8 }}>{Array.from({ length: 26 }).map((_, k) => <div key={k} style={{ width: 9, height: 54 * wave(f, k) * ramp(f, c.at + 6 + k * 0.6, c.at + 16 + k * 0.6), borderRadius: 6, background: k % 5 === 0 ? theme.colors.primary : theme.colors.textDim }} />)}</div>}
                    {i === 2 && <div style={{ height: 16, borderRadius: 10, marginTop: 22, background: theme.colors.surfaceHi, overflow: "hidden" }}><div style={{ width: `${100 * p}%`, height: "100%", background: theme.colors.primary, borderRadius: 10 }} /></div>}
                  </div>
                  <div style={{ opacity: ramp(f, c.at + 26, c.at + 32), transform: `scale(${0.5 + 0.5 * ramp(f, c.at + 26, c.at + 34, [0, 1], theme.ease.out)})` }}>
                    <div style={{ width: 62, height: 62, borderRadius: 62, background: theme.colors.primary, display: "flex", alignItems: "center", justifyContent: "center" }}><Icon name="check" size={38} color={theme.colors.ink} stroke={3} /></div>
                  </div>
                </div>
              </Glass>
            </Pop>
          </React.Fragment>
        );
      })}
    </AbsoluteFill>
  );
};

/** video -> upload -> monetization -> টাকা */
export const S3cFlikiMoney: React.FC = () => {
  const f = useCurrentFrame();
  const at = useAt();
  const X = [300, 960, 1620];
  const Y = 500;
  const n1 = at(10, 0), n2 = at(11, 0), n3 = at(11, 4), fin = at(12, 1);
  const seg1 = ramp(f, n2 - 18, n2 + 4, [0, 1], theme.ease.inOut);
  const seg2 = ramp(f, n3 - 20, n3 + 2, [0, 1], theme.ease.inOut);
  const node = (x: number, children: React.ReactNode, label: string, t: number) => (
    <Pop at={t} from={{ y: 50, s: 0.7 }} preset="bouncy" style={{ position: "absolute", left: x - 150, top: Y - 150 + Math.sin(f / 24 + x) * 5, width: 300 }}>
      <Glass style={{ width: 300, height: 300 }} radius={64}><div style={{ display: "flex", height: "100%", alignItems: "center", justifyContent: "center" }}>{children}</div></Glass>
      <div style={{ marginTop: 26, textAlign: "center", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 56, color: theme.colors.text }}>{label}</div>
    </Pop>
  );
  return (
    <AbsoluteFill>
      <Sfx at={n1} name="pop" vol={0.28} />
      <Sfx at={n2} name="pop" vol={0.28} rate={1.05} />
      <Sfx at={fin} name="chime" vol={0.3} />
      <div style={{ position: "absolute", left: 0, right: 0, top: 90, display: "flex", justifyContent: "center" }}>
        <Words text="আপনার কাজ শুধু" at={0} times={[2, 3, 4].map((i) => at(10, i))} size={96} hi={[2]} />
      </div>
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <line x1={X[0] + 150} y1={Y} x2={X[1] - 150} y2={Y} stroke={theme.colors.surfaceHi} strokeWidth={8} strokeLinecap="round" />
        <line x1={X[1] + 150} y1={Y} x2={X[2] - 150} y2={Y} stroke={theme.colors.surfaceHi} strokeWidth={8} strokeLinecap="round" />
        <line x1={X[0] + 150} y1={Y} x2={X[0] + 150 + (X[1] - X[0] - 300) * seg1} y2={Y} stroke={theme.colors.primary} strokeWidth={8} strokeLinecap="round" />
        <line x1={X[1] + 150} y1={Y} x2={X[1] + 150 + (X[2] - X[1] - 300) * seg2} y2={Y} stroke={theme.colors.primary} strokeWidth={8} strokeLinecap="round" />
      </svg>
      {node(X[0], <Icon name="video" size={140} color={theme.colors.text} />, "Video", n1)}
      {node(X[1], <div style={{ transform: `translateY(${-Math.abs(Math.sin(f / 9)) * 6}px)` }}><LogoCard logo="youtube" h={118} radius={22} /></div>, "Upload", n2)}
      {node(X[2], <Coin size={170} spin={0.8} />, "Monetization", n3)}
      <Pop at={n2 + 8} from={{ y: 30, s: 0.4 }} preset="bouncy" style={{ position: "absolute", left: X[1] - 40, top: Y - 215 }}><Icon name="upload" size={80} color={theme.colors.primary} stroke={2.4} /></Pop>
      <div style={{ position: "absolute", left: 0, right: 0, top: 830, display: "flex", justifyContent: "center" }}>
        <Words text="টাকা কামানো" at={0} times={[at(12, 1), at(12, 2)]} size={128} hi={[0, 1]} glow />
      </div>
      <CoinBurst at={fin} cx={X[2]} cy={Y} count={12} />
    </AbsoluteFill>
  );
};
