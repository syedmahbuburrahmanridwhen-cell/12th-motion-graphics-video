import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme, gold } from "../theme";
import { Coin, CoinBurst, Glass, Icon, Pop, Sfx, Words, ramp, useAt } from "../components/core";
import { Exit, Keycap } from "../components/parts";

const HUB = { x: 960, y: 540 };
const NODES = [
  { icon: "video", x: 400, y: 470 },
  { icon: "image", x: 1520, y: 470 },
  { icon: "book", x: 960, y: 900 },
] as const;

export const S2Hub: React.FC = () => {
  const f = useCurrentFrame();
  const at = useAt();
  const aOut = at(4, 0, 4);
  const bIn = at(4, 0);
  const kIn = at(4, 3, 10);
  const copyAt = at(4, 4, 0), pasteAt = at(4, 5, 0);
  const incomeAt = at(5, 0, 12);
  return (
    <AbsoluteFill>
      <Sfx at={at(3, 0)} name="pop" vol={0.28} />
      <Sfx at={copyAt} name="click" vol={0.3} />
      <Sfx at={pasteAt} name="click" vol={0.3} rate={1.08} />
      <Sfx at={incomeAt + 2} name="chime" vol={0.3} />

      {/* ---- beat A: hub & spoke — AI does the hard work ---- */}
      <Exit at={aOut}>
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
          {NODES.map((n, i) => {
            const t0 = at(3, 3) + i * 5;
            const p = ramp(f, t0, t0 + 16, [0, 1], theme.ease.inOut);
            const len = Math.hypot(n.x - HUB.x, n.y - HUB.y);
            const k = (f * 0.022 + i / 3) % 1;
            return (
              <g key={i} opacity={p}>
                <line x1={HUB.x} y1={HUB.y} x2={n.x} y2={n.y} stroke={theme.colors.primary} strokeOpacity={0.55} strokeWidth={4} strokeDasharray={`${len}`} strokeDashoffset={len * (1 - p)} strokeLinecap="round" />
                <circle cx={n.x + (HUB.x - n.x) * k} cy={n.y + (HUB.y - n.y) * k} r={9} fill={theme.colors.primary} />
              </g>
            );
          })}
        </svg>
        {[0, 1, 2].map((k) => {
          const t = ((f - at(3, 0)) / 46 + k / 3) % 1;
          const r = 120 + t * 230;
          return f > at(3, 0) ? <div key={k} style={{ position: "absolute", left: HUB.x - r, top: HUB.y - r, width: r * 2, height: r * 2, borderRadius: r * 2, border: `3px solid ${theme.colors.primary}`, opacity: 0.32 * (1 - t) }} /> : null;
        })}
        <Pop at={at(3, 0)} from={{ y: 0, s: 0.3 }} preset="bouncy" style={{ position: "absolute", left: HUB.x - 130, top: HUB.y - 130 }}>
          <div style={{ width: 260, height: 260, borderRadius: 260, background: gold, boxShadow: `0 0 120px ${theme.colors.glow}, inset 0 -18px 30px rgba(150,90,0,0.4)`, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 124, color: theme.colors.ink, transform: `scale(${1 + Math.sin(f / 12) * 0.025})` }}>AI</div>
        </Pop>
        {NODES.map((n, i) => (
          <Pop key={i} at={at(3, 3) + i * 5} from={{ y: 40, s: 0.6 }} preset="bouncy" style={{ position: "absolute", left: n.x - 100, top: n.y - 100 + Math.sin(f / 26 + i) * 5 }}>
            <Glass style={{ width: 200, height: 200 }} radius={52}>
              <div style={{ display: "flex", height: "100%", alignItems: "center", justifyContent: "center" }}><Icon name={n.icon} size={104} color={theme.colors.text} /></div>
            </Glass>
          </Pop>
        ))}
        <div style={{ position: "absolute", left: 0, right: 0, top: 110, display: "flex", justifyContent: "center" }}>
          <Words text="একাই সব কঠিন কাজ" at={0} times={[2, 3, 4, 5].map((i) => at(3, i))} size={104} />
        </div>
      </Exit>

      {/* ---- beat B: just copy-paste ---- */}
      <Exit at={incomeAt - 4}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 110, display: "flex", justifyContent: "center" }}>
          <Words text="কোন অভিজ্ঞতা ছাড়াই" at={0} times={[0, 1, 2].map((i) => at(4, i))} size={104} hi={[2]} />
        </div>
        <div style={{ position: "absolute", left: 130, top: 430, display: "flex", gap: 26 }}>
          <Keycap label="Ctrl" w={250} at={kIn} /><Keycap label="C" w={150} at={kIn + 4} pressAt={copyAt} />
        </div>
        <div style={{ position: "absolute", left: 1364, top: 430, display: "flex", gap: 26 }}>
          <Keycap label="Ctrl" w={250} at={kIn + 8} /><Keycap label="V" w={150} at={kIn + 12} pressAt={pasteAt} />
        </div>
        <Pop at={kIn + 14} preset="snappy" style={{ position: "absolute", left: 960 - 55, top: 505 - 55 }}><Icon name="arrow" size={110} color={theme.colors.textDim} /></Pop>
        <Pop at={kIn + 6} from={{ x: -30 }} style={{ position: "absolute", left: 675, top: 400 }}>
          <Glass style={{ width: 170, height: 210 }} radius={30}><div style={{ display: "flex", height: "100%", alignItems: "center", justifyContent: "center" }}><Icon name="doc" size={92} color={theme.colors.text} /></div></Glass>
        </Pop>
        <Pop at={pasteAt} from={{ x: -140, s: 0.7 }} preset="bouncy" style={{ position: "absolute", left: 1075, top: 400 }}>
          <Glass style={{ width: 170, height: 210 }} radius={30}><div style={{ display: "flex", height: "100%", alignItems: "center", justifyContent: "center" }}><Icon name="doc" size={92} color={theme.colors.text} /></div></Glass>
        </Pop>
        <Pop at={pasteAt + 6} from={{ s: 0.2 }} preset="bouncy" style={{ position: "absolute", left: 1075 + 170 - 40, top: 400 - 26 }}>
          <div style={{ width: 68, height: 68, borderRadius: 68, background: theme.colors.primary, display: "flex", alignItems: "center", justifyContent: "center" }}><Icon name="check" size={42} color={theme.colors.ink} stroke={3} /></div>
        </Pop>
        <Pop at={kIn + 2} style={{ position: "absolute", left: 130, top: 640, width: 426, textAlign: "center" }}><div style={{ fontFamily: theme.fonts.body, fontWeight: 500, fontSize: 46, color: theme.colors.textDim }}>copy</div></Pop>
        <Pop at={kIn + 10} style={{ position: "absolute", left: 1364, top: 640, width: 426, textAlign: "center" }}><div style={{ fontFamily: theme.fonts.body, fontWeight: 500, fontSize: 46, color: theme.colors.textDim }}>paste</div></Pop>
      </Exit>

      {/* ---- payoff: income ---- */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 360, display: "flex", justifyContent: "center", alignItems: "center", gap: 50 }}>
        <Pop at={incomeAt} from={{ s: 0.2, y: 0 }} preset="bouncy"><Coin size={250} spin={0.9} /></Pop>
        <Words text="income" at={incomeAt + 4} size={300} hi={[0]} glow />
      </div>
      <CoinBurst at={incomeAt + 2} cx={960} cy={500} count={16} power={1.1} />
    </AbsoluteFill>
  );
};
