import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme, gold } from "../theme";
import { Coin, CoinBurst, Glass, Icon, LogoCard, Pop, Sfx, TypedWords, Window, Words, ramp, useAt } from "../components/core";
import { Chip, Exit, NumberBadge } from "../components/parts";

/** 03 — intro */
export const S5aBookIntro: React.FC = () => {
  const f = useCurrentFrame();
  const at = useAt();
  const logoAt = at(20, 3);
  return (
    <AbsoluteFill>
      <Sfx at={at(20, 1)} name="whoosh" vol={0.26} />
      <Sfx at={logoAt} name="pluck" vol={0.3} />
      <div style={{ position: "absolute", left: 60, top: 140, width: 800, height: 800, borderRadius: 800, background: `radial-gradient(circle, ${theme.colors.glowSoft}, transparent 66%)`, transform: `scale(${1 + Math.sin(f / 30) * 0.04})` }} />
      <Pop at={logoAt} from={{ x: -120, s: 0.6, r: -8 }} preset="bouncy" style={{ position: "absolute", left: 200, top: 310 + Math.sin(f / 28) * 9 }}>
        <div style={{ transform: `perspective(1800px) rotateY(${11 + Math.sin(f / 40) * 3}deg) rotateX(3deg)` }}><LogoCard logo="bookbolt" h={460} radius={56} glow /></div>
      </Pop>
      <NumberBadge n={3} at={at(20, 1)} style={{ position: "absolute", left: 860, top: 120 }} />
      <Words text="Book Bolt" at={0} times={[at(20, 3), at(20, 4)]} size={210} align="left" style={{ position: "absolute", left: 860, top: 450 }} />
      <Pop at={at(20, 5)} from={{ y: 20 }} style={{ position: "absolute", left: 866, top: 740 }}>
        <Icon name="bolt" size={72} color={theme.colors.primary} stroke={2.2} />
      </Pop>
    </AbsoluteFill>
  );
};

const Illustration: React.FC = () => (
  <svg width={380} height={520} viewBox="0 0 380 520">
    <rect width="380" height="520" fill={theme.colors.paper} />
    <rect x="30" y="40" width="320" height="300" rx="20" fill={theme.colors.primary} opacity="0.9" />
    <circle cx="270" cy="110" r="38" fill={theme.colors.paper} />
    <path d="M30 300 Q 120 200 210 280 T 350 260 V340 H30z" fill={theme.colors.ink} opacity="0.85" />
    <rect x="120" y="230" width="14" height="60" fill={theme.colors.bg} />
    <circle cx="127" cy="215" r="42" fill={theme.colors.accent} />
    <g transform="translate(220,160)" fill={theme.colors.ink}><path d="M0 0 Q 16 -16 32 0 Q 48 -16 64 0 Q 48 -2 32 8 Q 16 -2 0 0z" /></g>
    {[390, 425, 460].map((y, i) => <rect key={i} x="40" y={y} width={[300, 240, 270][i]} height="14" rx="7" fill={theme.colors.ink} opacity="0.18" />)}
  </svg>
);
const Lines: React.FC<{ p: number; seed?: number }> = ({ p, seed = 0 }) => (
  <div style={{ position: "absolute", inset: 0, background: theme.colors.paper, padding: "56px 40px" }}>
    <div style={{ width: 120, height: 20, borderRadius: 10, background: theme.colors.primary, marginBottom: 34 }} />
    {[1, 0.92, 0.97, 0.7, 1, 0.88, 0.95, 0.6, 0.9, 0.78].map((w, i) => <div key={i} style={{ height: 14, borderRadius: 7, marginBottom: 26, width: `${w * 100 * Math.min(1, Math.max(0, p * 12 - i * 0.9 - seed))}%`, background: theme.colors.ink, opacity: 0.2 }} />)}
  </div>
);

/** chat prompt -> a whole book (text + pictures) */
export const S5bBookBuild: React.FC = () => {
  const f = useCurrentFrame();
  const at = useAt();
  const typed = [{ text: "বাচ্চাদের", at: at(21, 2) }, { text: "জন্য", at: at(21, 3) }, { text: "একটি", at: at(21, 4) }, { text: "শিক্ষণীয়", at: at(21, 5) }, { text: "গল্প", at: at(22, 0) }];
  const aiAt = at(22, 3), fast = at(22, 4), bookAt = at(22, 3, 8), flipAt = at(23, 0, 4);
  const prog = ramp(f, fast, fast + 22, [0, 1], theme.ease.inOut);
  const flip = ramp(f, flipAt, flipAt + 26, [0, 1], theme.ease.inOut);
  const textP = ramp(f, fast + 4, fast + 40, [0, 1], theme.ease.inOut);
  return (
    <AbsoluteFill>
      <Sfx at={at(21, 1)} name="pop" vol={0.28} />
      <Sfx at={fast} name="whoosh" vol={0.24} />
      <Sfx at={bookAt} name="pop" vol={0.28} />
      <Sfx at={flipAt + 4} name="swipe" vol={0.2} />
      <Sfx at={at(23, 4)} name="chime" vol={0.3} />
      <Pop at={0} from={{ y: -20 }} style={{ position: "absolute", left: 100, top: 60, display: "flex", alignItems: "center", gap: 20 }}>
        <LogoCard logo="bookbolt" h={80} radius={20} />
        <div style={{ fontFamily: theme.fonts.body, fontWeight: 700, fontSize: 46, color: theme.colors.textDim }}>Book Bolt</div>
      </Pop>
      <Pop at={at(21, 0, 8)} from={{ x: -60 }} style={{ position: "absolute", left: 100, top: 190, width: 800, height: 620 }}>
        <Window style={{ width: 800, height: 620 }} title="Chat">
          <div style={{ padding: "36px 40px", display: "flex", flexDirection: "column", gap: 30 }}>
            <div style={{ alignSelf: "flex-end", maxWidth: 640, borderRadius: "34px 34px 8px 34px", background: theme.colors.surfaceHi, border: `1px solid ${theme.colors.border}`, padding: "26px 34px" }}>
              <TypedWords words={typed} size={50} />
            </div>
            <Pop at={aiAt} from={{ x: -40, y: 20 }} style={{ alignSelf: "flex-start", width: 640 }}>
              <div style={{ borderRadius: "34px 34px 34px 8px", background: theme.colors.bg, border: `2px solid ${theme.colors.primary}55`, padding: "26px 34px", boxShadow: `0 0 50px ${theme.colors.glowSoft}` }}>
                <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
                  <Icon name="bolt" size={58} color={theme.colors.primary} stroke={2.2} />
                  <div style={{ flex: 1, height: 20, borderRadius: 10, background: theme.colors.surfaceHi, overflow: "hidden" }}><div style={{ width: `${prog * 100}%`, height: "100%", background: theme.colors.primary, borderRadius: 10 }} /></div>
                  {prog >= 1 && <Pop at={fast + 22} from={{ s: 0.2 }} preset="bouncy"><div style={{ width: 54, height: 54, borderRadius: 54, background: theme.colors.primary, display: "flex", alignItems: "center", justifyContent: "center" }}><Icon name="check" size={34} color={theme.colors.ink} stroke={3.2} /></div></Pop>}
                </div>
                <div style={{ display: "flex", gap: 14, marginTop: 24 }}>
                  {[0, 1, 2].map((k) => <div key={k} style={{ width: 14, height: 14, borderRadius: 14, background: theme.colors.textDim, opacity: prog < 1 ? 0.3 + 0.7 * Math.abs(Math.sin(f / 5 + k)) : 0.3 }} />)}
                </div>
              </div>
            </Pop>
          </div>
        </Window>
      </Pop>
      {/* book spread */}
      <Pop at={bookAt} from={{ y: 70, s: 0.85 }} preset="smooth" style={{ position: "absolute", left: 1010, top: 250 + Math.sin(f / 30) * 5 }}>
        <div style={{ position: "relative", width: 800, height: 540, perspective: 2400 }}>
          <div style={{ position: "absolute", inset: -14, borderRadius: 30, background: gold, boxShadow: `0 40px 80px -20px rgba(0,0,0,0.8), 0 0 90px ${theme.colors.glowSoft}` }} />
          <div style={{ position: "absolute", left: 10, top: 10, width: 380, height: 520, background: theme.colors.paper, borderRadius: "14px 0 0 14px" }} />
          <div style={{ position: "absolute", left: 410, top: 10, width: 380, height: 520, borderRadius: "0 14px 14px 0", overflow: "hidden" }}><Lines p={1} seed={2} /></div>
          <div style={{ position: "absolute", left: 398, top: 10, width: 24, height: 520, background: "linear-gradient(90deg, transparent, rgba(0,0,0,0.28), transparent)" }} />
          <div style={{ position: "absolute", left: 410, top: 10, width: 380, height: 520, transformOrigin: "left center", transform: `rotateY(${-180 * flip}deg)`, transformStyle: "preserve-3d" }}>
            <div style={{ position: "absolute", inset: 0, backfaceVisibility: "hidden", borderRadius: "0 14px 14px 0", overflow: "hidden" }}><Lines p={textP} /></div>
            <div style={{ position: "absolute", inset: 0, backfaceVisibility: "hidden", transform: "rotateY(180deg)", borderRadius: "14px 0 0 14px", overflow: "hidden" }}><Illustration /></div>
          </div>
        </div>
      </Pop>
      <div style={{ position: "absolute", left: 1010, top: 130, display: "flex", gap: 22 }}>
        <Chip at={at(23, 0)} icon="doc" text="গল্প" size={44} />
        <Chip at={at(23, 2)} icon="image" text="ছবি" size={44} />
      </div>
      <div style={{ position: "absolute", left: 1010, width: 800, top: 850, display: "flex", justifyContent: "center", alignItems: "center", gap: 26 }}>
        <Words text="পুরো বই" at={0} times={[at(23, 4), at(23, 5)]} size={110} hi={[0, 1]} glow />
        <Pop at={at(23, 6)} from={{ s: 0.2 }} preset="bouncy"><div style={{ width: 76, height: 76, borderRadius: 76, background: theme.colors.primary, display: "flex", alignItems: "center", justifyContent: "center" }}><Icon name="check" size={48} color={theme.colors.ink} stroke={3.2} /></div></Pop>
      </div>
    </AbsoluteFill>
  );
};

/** publish on Amazon -> passive income */
export const S5cAmazon: React.FC = () => {
  const f = useCurrentFrame();
  const at = useAt();
  const pub = at(24, 2, 2);
  const press = ramp(f, pub, pub + 3) * (1 - ramp(f, pub + 8, pub + 14));
  const done = f >= pub + 4;
  const inc = at(25, 0);
  return (
    <AbsoluteFill>
      <Sfx at={at(24, 0)} name="pop" vol={0.28} />
      <Sfx at={at(24, 1)} name="pluck" vol={0.3} />
      <Sfx at={pub} name="click" vol={0.3} />
      <Sfx at={inc} name="chime" vol={0.3} />
      <Pop at={at(24, 0)} from={{ x: -60, s: 0.8, r: -8 }} preset="bouncy" style={{ position: "absolute", left: 110, top: 330 + Math.sin(f / 26) * 6 }}>
        <div style={{ width: 250, height: 340, borderRadius: "16px 28px 28px 16px", background: gold, boxShadow: `0 30px 60px -20px rgba(0,0,0,0.8), inset 14px 0 0 rgba(120,70,0,0.35)`, display: "flex", alignItems: "center", justifyContent: "center" }}><Icon name="book" size={130} color={theme.colors.ink} stroke={1.6} /></div>
      </Pop>
      <Pop at={at(24, 0, 0) + 6} preset="snappy" style={{ position: "absolute", left: 395, top: 458 }}><Icon name="arrow" size={110} color={theme.colors.textDim} /></Pop>
      <Pop at={at(24, 1)} from={{ s: 0.7 }} preset="bouncy" style={{ position: "absolute", left: 540, top: 250 + Math.sin(f / 28 + 1) * 6 }}><LogoCard logo="amazon" h={400} radius={36} /></Pop>
      <Pop at={at(24, 2, 8)} from={{ y: 40 }} style={{ position: "absolute", left: 540, top: 700, width: 524, display: "flex", justifyContent: "center" }}>
        <div style={{ height: 112, borderRadius: 56, padding: "0 56px", display: "flex", alignItems: "center", gap: 18, background: done ? theme.colors.surface : theme.colors.primary, color: done ? theme.colors.text : theme.colors.ink, border: done ? `2px solid ${theme.colors.primary}` : "none", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 52, transform: `scale(${1 - press * 0.06})`, boxShadow: `0 0 ${40 + press * 40}px ${theme.colors.glow}` }}>
          <Icon name={done ? "check" : "upload"} size={52} color={done ? theme.colors.primary : theme.colors.ink} stroke={3} /> {done ? "Published" : "Publish"}
        </div>
      </Pop>
      <div style={{ position: "absolute", left: 1150, top: 290, display: "flex", flexDirection: "column", alignItems: "flex-start" }}>
        <Words text="passive" at={0} times={[at(25, 0)]} size={170} align="left" />
        <Words text="income" at={0} times={[at(25, 1)]} size={170} align="left" hi={[0]} glow />
      </div>
      <Pop at={inc + 4} from={{ s: 0.2 }} preset="bouncy" style={{ position: "absolute", left: 1560, top: 700 }}><Coin size={190} spin={0.8} /></Pop>
      <CoinBurst at={inc} cx={1500} cy={560} count={12} />
    </AbsoluteFill>
  );
};
