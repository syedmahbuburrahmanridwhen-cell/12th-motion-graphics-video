import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme, gold } from "../theme";
import { Glass, Icon, LogoCard, Pop, Sfx, Window, Words, ramp, useAt } from "../components/core";
import { Chip, Exit } from "../components/parts";

/** Before/After balance: প্রথাগত skill vs AI ব্যবহারের বুদ্ধি */
export const S6Balance: React.FC = () => {
  const f = useCurrentFrame();
  const at = useAt();
  const aOut = at(26, 0, 2);
  const lAt = at(26, 3), rAt = at(26, 6);
  const tip = ramp(f, rAt, rAt + 26, [0, 1], theme.ease.out);
  const th = ((10 * tip + Math.sin(f / 18) * 0.6 * tip) * Math.PI) / 180;
  const P = { x: 960, y: 360 }, L = 520;
  const lx = P.x - L * Math.cos(th), ly = P.y - L * Math.sin(th), rx = P.x + L * Math.cos(th), ry = P.y + L * Math.sin(th);
  const drop = 170;
  return (
    <AbsoluteFill>
      <Sfx at={at(25, 2)} name="whoosh" vol={0.24} />
      <Sfx at={lAt} name="pop" vol={0.28} />
      <Sfx at={rAt} name="pluck" vol={0.3} />
      <Sfx at={at(27, 2)} name="click" vol={0.3} />
      {/* beat A: kinetic */}
      <Exit at={aOut}>
        <div style={{ position: "absolute", left: 660, top: 190, width: 600, height: 600, borderRadius: 600, border: `3px dashed ${theme.colors.border}`, transform: `rotate(${f * 0.6}deg)` }} />
        <div style={{ position: "absolute", left: 0, right: 0, top: 330, display: "flex", justifyContent: "center" }}>
          <Words text="বর্তমানে AI-এর যুগে" at={0} times={[2, 3, 4].map((i) => at(25, i))} size={160} hi={[1]} glow />
        </div>
      </Exit>
      {/* beat B: balance */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 60, display: "flex", justifyContent: "center" }}>
        <Words text="সফল হতে গেলে" at={0} times={[0, 1, 2].map((i) => at(26, i, 0))} size={80} color={theme.colors.textDim} />
      </div>
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <g opacity={ramp(f, at(26, 1), at(26, 1) + 14)}>
          <path d={`M${P.x} ${P.y} L${P.x - 70} 930 H${P.x + 70} Z`} fill={theme.colors.surfaceHi} />
          <rect x={P.x - 170} y={925} width={340} height={22} rx={11} fill={theme.colors.surface} />
          <line x1={lx} y1={ly} x2={rx} y2={ry} stroke={theme.colors.text} strokeWidth={14} strokeLinecap="round" />
          <circle cx={P.x} cy={P.y} r={26} fill={theme.colors.primary} />
          <line x1={lx} y1={ly} x2={lx} y2={ly + drop} stroke={theme.colors.textDim} strokeWidth={4} />
          <line x1={rx} y1={ry} x2={rx} y2={ry + drop} stroke={theme.colors.textDim} strokeWidth={4} />
        </g>
      </svg>
      <Pop at={lAt} from={{ y: -40, s: 0.8 }} preset="bouncy" style={{ position: "absolute", left: lx - 250, top: ly + drop }}>
        <Glass style={{ width: 500, height: 230, opacity: 0.8 }} radius={40}>
          <div style={{ display: "flex", height: "100%", alignItems: "center", justifyContent: "center", gap: 24, padding: "0 20px" }}>
            <Icon name="doc" size={84} color={theme.colors.textDim} />
            <div style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 56, color: theme.colors.textDim, lineHeight: 1.3 }}>প্রথাগত skill</div>
          </div>
        </Glass>
      </Pop>
      <Pop at={rAt} from={{ y: -60, s: 0.8 }} preset="bouncy" style={{ position: "absolute", left: rx - 270, top: ry + drop }}>
        <div style={{ width: 540, height: 230, borderRadius: 40, background: gold, boxShadow: `0 0 90px ${theme.colors.glow}, 0 30px 60px -20px rgba(0,0,0,0.7)`, display: "flex", alignItems: "center", justifyContent: "center", gap: 22, padding: "0 20px" }}>
          <Icon name="spark" size={84} color={theme.colors.ink} stroke={2} />
          <div style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 52, color: theme.colors.ink, lineHeight: 1.25 }}>AI ব্যবহারের বুদ্ধি</div>
        </div>
      </Pop>
      <Pop at={at(27, 2)} from={{ y: 20, s: 0.5 }} preset="bouncy" style={{ position: "absolute", left: rx + 130, top: ry + drop - 60 }}>
        <Chip at={0} text="আসল" size={50} hot />
      </Pop>
    </AbsoluteFill>
  );
};

/** Recap grid + save */
export const S7Recap: React.FC = () => {
  const f = useCurrentFrame();
  const at = useAt();
  const base = at(27, 3);
  const cards = [
    { logo: "fliki", h: 150, n: "01", name: "Fliki.ai", sub: "Faceless YouTube" },
    { logo: "midjourney", h: 190, n: "02", name: "Midjourney", sub: "AI ছবি" },
    { logo: "bookbolt", h: 190, n: "03", name: "Book Bolt", sub: "বাচ্চাদের বই" },
  ] as const;
  const save = at(29, 4, 2);
  const press = ramp(f, save, save + 3) * (1 - ramp(f, save + 8, save + 14));
  const saved = f >= save + 4;
  const cur = ramp(f, save - 24, save - 2, [0, 1], theme.ease.inOut);
  return (
    <AbsoluteFill>
      <Sfx at={base} name="whoosh" vol={0.24} />
      <Sfx at={base + 14} name="click" vol={0.3} />
      <Sfx at={base + 20} name="click" vol={0.3} rate={1.06} />
      <Sfx at={save} name="click" vol={0.3} />
      <Sfx at={save + 3} name="chime" vol={0.28} />
      <div style={{ position: "absolute", left: 0, right: 0, top: 60, display: "flex", justifyContent: "center" }}>
        <Words text="আজই শুরু করুন" at={0} times={[at(27, 6), at(28, 0), at(28, 1)]} size={120} hi={[0]} glow />
      </div>
      {cards.map((c, i) => {
        const t = base + i * 7;
        const ck = ramp(f, t + 14, t + 24, [0, 1], theme.ease.out);
        return (
          <Pop key={i} at={t} from={{ y: 70, s: 0.9 }} preset="smooth" style={{ position: "absolute", left: 150 + i * 550, top: 260 + Math.sin(f / 26 + i) * 5 }}>
            <Glass style={{ width: 520, height: 470 }} radius={44}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", paddingTop: 40, gap: 26, height: "100%" }}>
                <div style={{ height: 190, display: "flex", alignItems: "center" }}><LogoCard logo={c.logo} h={c.h} radius={26} /></div>
                <div style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 64, color: theme.colors.text, lineHeight: 1.25 }}>{c.name}</div>
                <div style={{ fontFamily: theme.fonts.body, fontWeight: 500, fontSize: 40, color: theme.colors.textDim, lineHeight: 1.3 }}>{c.sub}</div>
              </div>
              <div style={{ position: "absolute", left: 28, top: 24, fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 40, color: theme.colors.textDim }}>{c.n}</div>
              <div style={{ position: "absolute", right: 26, top: 22, width: 66, height: 66, borderRadius: 66, background: theme.colors.primary, display: "flex", alignItems: "center", justifyContent: "center", opacity: ck, transform: `scale(${0.4 + 0.6 * ck})` }}><Icon name="check" size={42} color={theme.colors.ink} stroke={3.2} /></div>
            </Glass>
          </Pop>
        );
      })}
      <Pop at={at(28, 3)} from={{ y: 50 }} preset="snappy" style={{ position: "absolute", left: 0, right: 0, top: 800, display: "flex", justifyContent: "center" }}>
        <div style={{ height: 130, borderRadius: 65, padding: "0 70px", display: "flex", alignItems: "center", gap: 22, background: saved ? theme.colors.primary : theme.colors.surface, color: saved ? theme.colors.ink : theme.colors.text, border: `2px solid ${saved ? "transparent" : theme.colors.border}`, fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 60, transform: `scale(${1 - press * 0.06})`, boxShadow: saved ? `0 0 80px ${theme.colors.glow}` : theme.shadow.pop }}>
          <div style={{ transform: `scale(${saved ? 1.15 : 1})` }}><Icon name={saved ? "check" : "bookmark"} size={62} color={saved ? theme.colors.ink : theme.colors.primary} stroke={saved ? 3.2 : 2} /></div>
          {saved ? "Saved" : "Save"}
        </div>
      </Pop>
      <div style={{ position: "absolute", left: 1180 + (1 - cur) * 200, top: 880 + (1 - cur) * 120, opacity: cur }}><Icon name="cursor" size={70} color={theme.colors.text} /></div>
    </AbsoluteFill>
  );
};

/** Website -> inbox -> ধন্যবাদ */
export const S8Cta: React.FC = () => {
  const f = useCurrentFrame();
  const at = useAt();
  const w0 = at(30, 3);
  const p1Out = at(32, 4, 8);
  const inbox = at(32, 5);
  const p2Out = at(33, 2, 12);
  const end = at(33, 2, 10);
  const rows = [
    { t: at(30, 3), icon: "spark", text: "personal brand" },
    { t: at(31, 0), icon: "globe", text: "business" },
    { t: at(31, 2), icon: "check", text: "professional website" },
  ] as const;
  const fadeOut = ramp(f, 218, 228, [1, 0], theme.ease.in);
  const blk = (t: number, style: React.CSSProperties) => <Pop at={t} from={{ y: 24, s: 0.92 }} preset="snappy" style={{ position: "absolute", ...style }}><div style={{ width: "100%", height: "100%", borderRadius: (style.borderRadius as number) ?? 18, background: (style.background as string) ?? theme.colors.surfaceHi }} /></Pop>;
  return (
    <AbsoluteFill style={{ opacity: fadeOut }}>
      <Sfx at={w0 - 6} name="pop" vol={0.28} />
      <Sfx at={rows[0].t} name="click" vol={0.3} />
      <Sfx at={rows[2].t} name="chime" vol={0.28} />
      <Sfx at={inbox} name="pop" vol={0.3} />
      <Sfx at={end} name="pluck" vol={0.3} />
      <Exit at={p1Out}>
        <Pop at={at(30, 0, 8)} from={{ x: -60, s: 0.94 }} style={{ position: "absolute", left: 110, top: 190, width: 1120, height: 700 }}>
          <Window style={{ width: 1120, height: 700 }}>
            <div style={{ position: "absolute", left: 40, top: 20, right: 40, height: 56, borderRadius: 28, background: theme.colors.bg, border: `1px solid ${theme.colors.border}`, display: "flex", alignItems: "center", padding: "0 22px", gap: 14 }}>
              <Icon name="globe" size={30} color={theme.colors.textDim} /><div style={{ width: 280, height: 14, borderRadius: 7, background: theme.colors.surfaceHi }} />
            </div>
            {blk(w0 + 2, { left: 40, top: 110, width: 56, height: 56, borderRadius: 56, background: theme.colors.primary })}
            {[0, 1, 2].map((i) => blk(w0 + 6 + i * 3, { left: 640 + i * 150, top: 126, width: 120, height: 24, borderRadius: 12 }))}
            {blk(w0 + 12, { left: 40, top: 220, width: 460, height: 40, borderRadius: 20, background: theme.colors.text })}
            {blk(w0 + 16, { left: 40, top: 284, width: 330, height: 40, borderRadius: 20, background: theme.colors.text })}
            {blk(w0 + 20, { left: 40, top: 360, width: 360, height: 20, borderRadius: 10 })}
            {blk(w0 + 24, { left: 40, top: 430, width: 220, height: 70, borderRadius: 35, background: theme.colors.primary })}
            {blk(w0 + 18, { left: 600, top: 200, width: 480, height: 300, borderRadius: 30, background: "linear-gradient(135deg, rgba(245,185,58,0.38), rgba(255,122,69,0.28))" })}
            {[0, 1, 2].map((i) => blk(w0 + 28 + i * 4, { left: 40 + i * 345, top: 530, width: 320, height: 80, borderRadius: 24 }))}
          </Window>
        </Pop>
        <div style={{ position: "absolute", left: 1250, top: 260, display: "flex", flexDirection: "column", gap: 34 }}>
          {rows.map((r, i) => (
            <Pop key={i} at={r.t} from={{ x: 80, s: 0.9 }} preset="bouncy">
              <div style={{ display: "flex", alignItems: "center", gap: 22, padding: "26px 36px", borderRadius: 999, background: theme.colors.surface, border: `1px solid ${theme.colors.border}`, boxShadow: theme.shadow.pop, fontFamily: theme.fonts.body, fontWeight: 700, fontSize: 42, color: theme.colors.text, lineHeight: 1.3, width: 570, whiteSpace: "nowrap" }}>
                <Icon name={r.icon} size={52} />{r.text}
              </div>
            </Pop>
          ))}
        </div>
      </Exit>
      <Exit at={p2Out}>
        <Pop at={inbox} from={{ y: 60, s: 0.4 }} preset="bouncy" style={{ position: "absolute", left: 960 - 130, top: 250 }}>
          <div style={{ position: "relative", width: 260, height: 260, borderRadius: 70, background: gold, boxShadow: `0 0 110px ${theme.colors.glow}`, display: "flex", alignItems: "center", justifyContent: "center", transform: `rotate(${Math.sin(f / 6) * (f < inbox + 24 ? 6 : 0)}deg)` }}>
            <Icon name="mail" size={150} color={theme.colors.ink} stroke={1.8} />
            <div style={{ position: "absolute", right: -10, top: -10, width: 54, height: 54, borderRadius: 54, background: theme.colors.accent, transform: `scale(${1 + 0.12 * Math.sin(f / 5)})` }} />
          </div>
        </Pop>
        <div style={{ position: "absolute", left: 0, right: 0, top: 560, display: "flex", justifyContent: "center" }}>
          <Words text="inbox" at={0} times={[inbox + 2]} size={200} />
        </div>
      </Exit>
      <div style={{ position: "absolute", left: 0, right: 0, top: 330, display: "flex", justifyContent: "center" }}>
        <Words text="ধন্যবাদ" at={0} times={[end]} size={270} hi={[0]} glow />
      </div>
      {f >= end && [0, 1, 2, 3, 4].map((i) => <Pop key={i} at={end + 6 + i * 3} from={{ s: 0.2, r: 90 }} preset="bouncy" style={{ position: "absolute", left: [520, 1360, 700, 1230, 960][i], top: [330, 380, 650, 640, 240][i] + Math.sin(f / 18 + i) * 8 }}><Icon name="spark" size={[56, 46, 40, 52, 36][i]} color={i % 2 ? theme.colors.accent : theme.colors.primary} /></Pop>)}
    </AbsoluteFill>
  );
};
