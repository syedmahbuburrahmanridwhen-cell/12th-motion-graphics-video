import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme, gold } from "../theme";
import { Coin, CoinBurst, Glass, Icon, LogoCard, Pop, Sfx, TypedWords, Window, Words, ramp, useAt } from "../components/core";
import { Chip, Exit, NumberBadge } from "../components/parts";

/** Little generated "artwork" tile (sky + sun + hills + bird) — drawn in theme colors. */
const Art: React.FC<{ v: number; w: number; h: number }> = ({ v, w, h }) => {
  const skies = [[theme.colors.primary, theme.colors.accent], ["#FFE3A0", theme.colors.primary], [theme.colors.surfaceHi, theme.colors.accent], [theme.colors.accent, "#3a1f14"]];
  const [a, b] = skies[v % 4];
  const bx = [0.62, 0.3, 0.7, 0.45][v % 4], by = [0.3, 0.26, 0.34, 0.28][v % 4];
  return (
    <svg width={w} height={h} viewBox="0 0 380 300">
      <defs><linearGradient id={`sky${v}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={a} /><stop offset="1" stopColor={b} /></linearGradient></defs>
      <rect width="380" height="300" fill={`url(#sky${v})`} />
      <circle cx={[290, 90, 300, 110][v % 4]} cy={[90, 100, 80, 90][v % 4]} r="46" fill={theme.colors.paper} opacity="0.85" />
      <path d="M0 230 Q 80 150 170 215 T 380 190 V300 H0z" fill={theme.colors.ink} opacity="0.8" />
      <path d="M0 262 Q 110 205 220 255 T 380 235 V300 H0z" fill={theme.colors.bg} />
      <g transform={`translate(${380 * bx - 36}, ${300 * by}) scale(${1.1 + (v % 2) * 0.3})`} fill={theme.colors.ink}>
        <path d="M0 0 Q 18 -18 36 0 Q 54 -18 72 0 Q 54 -3 36 9 Q 18 -3 0 0z" />
      </g>
    </svg>
  );
};

export const S4aMidjourney: React.FC = () => {
  const f = useCurrentFrame();
  const at = useAt();
  const logoAt = at(13, 0);
  const shr = at(13, 3, 10);
  const winAt = at(13, 4);
  const gen = at(15, 2);
  const tileAt = (i: number) => at(15, 5) + i * 6;
  // logo: centered hero -> header chip
  const m = ramp(f, shr, shr + 20, [0, 1], theme.ease.inOut);
  const hLogo = 360 + (70 - 360) * m;
  const lx = 720 + (120 - 720) * m, ly = 330 + (62 - 330) * m;
  const winX = interpolate(ramp(f, gen, gen + 24, [0, 1], theme.ease.inOut), [0, 1], [550, 110]);
  const typed = [{ text: "একটি", at: at(14, 3) }, { text: "সুন্দর", at: at(14, 4) }, { text: "পাখির", at: at(14, 5) }, { text: "নান্দনিক", at: at(15, 0) }, { text: "ছবি", at: at(15, 1) }];
  const press = ramp(f, gen - 2, gen + 1) * (1 - ramp(f, gen + 6, gen + 12));
  const art = [0, 1, 2, 3];
  return (
    <AbsoluteFill>
      <Sfx at={logoAt} name="pluck" vol={0.3} />
      <Sfx at={at(12, 3, 2)} name="whoosh" vol={0.24} />
      <Sfx at={winAt} name="pop" vol={0.28} />
      <Sfx at={gen} name="click" vol={0.3} />
      <Sfx at={tileAt(0)} name="pop" vol={0.28} />
      <Sfx at={at(16, 1)} name="chime" vol={0.28} />
      {/* beat a: intro */}
      <Exit at={shr - 2}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 50, display: "flex", justifyContent: "center" }}>
          <NumberBadge n={2} at={2} size={170} style={{ display: "flex", flexDirection: "column", alignItems: "center" }} />
        </div>
        <Words text="Midjourney" at={0} times={[at(13, 0)]} size={180} style={{ position: "absolute", left: 0, right: 0, top: 735 }} />
      </Exit>
      <Pop at={logoAt} from={{ y: 70, s: 0.6, r: -6 }} preset="bouncy" style={{ position: "absolute", left: lx, top: ly + (m < 0.01 ? Math.sin(f / 26) * 8 : 0) }}>
        <LogoCard logo="midjourney" h={hLogo} radius={Math.round(36 - 20 * m)} glow={m < 0.5} />
      </Pop>
      {/* beat b/c: prompt -> images */}
      <Pop at={winAt} from={{ y: 60, s: 0.9 }} style={{ position: "absolute", left: winX, top: 230, width: 820, height: 560 }}>
        <Window style={{ width: 820, height: 560 }} title="Prompt">
          <div style={{ padding: "36px 44px" }}>
            <div style={{ fontFamily: theme.fonts.body, fontWeight: 700, fontSize: 34, color: theme.colors.textDim, marginBottom: 20 }}>prompt</div>
            <div style={{ minHeight: 200, borderRadius: 26, background: theme.colors.bg, border: `2px solid ${theme.colors.primary}55`, padding: "26px 32px", boxShadow: `0 0 50px ${theme.colors.glowSoft}` }}>
              <TypedWords words={typed} size={60} />
            </div>
            <div style={{ marginTop: 28, display: "flex", justifyContent: "flex-end" }}>
              <div style={{ height: 78, borderRadius: 40, padding: "0 38px", display: "flex", alignItems: "center", gap: 14, background: theme.colors.primary, color: theme.colors.ink, fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 40, transform: `scale(${1 - press * 0.06})`, boxShadow: `0 0 ${40 + press * 40}px ${theme.colors.glow}` }}>
                <Icon name="spark" size={40} color={theme.colors.ink} stroke={2.4} /> AI
              </div>
            </div>
          </div>
        </Window>
      </Pop>
      {art.map((i) => {
        const col = i % 2, row = Math.floor(i / 2);
        const x = 1000 + col * 410, y = 200 + row * 330;
        const rv = ramp(f, tileAt(i), tileAt(i) + 16);
        return (
          <Pop key={i} at={gen + 4 + i * 3} from={{ x: 60, s: 0.9 }} preset="snappy" style={{ position: "absolute", left: x, top: y + Math.sin(f / 22 + i) * 6 }}>
            <Glass style={{ width: 380, height: 300 }} radius={30}>
              <div style={{ opacity: rv, filter: `blur(${(1 - rv) * 22}px)`, transform: `scale(${1.08 - 0.08 * rv})` }}><Art v={i} w={380} h={300} /></div>
              <div style={{ position: "absolute", inset: 0, opacity: 1 - rv, background: `linear-gradient(110deg, transparent ${((f * 3 + i * 40) % 160) - 30}%, ${theme.colors.glowSoft} ${((f * 3 + i * 40) % 160)}%, transparent ${((f * 3 + i * 40) % 160) + 30}%)` }} />
            </Glass>
          </Pop>
        );
      })}
      <Pop at={at(16, 1)} from={{ y: 20, s: 0.7 }} preset="bouncy" style={{ position: "absolute", left: 1000, top: 110 }}><Chip at={0} icon="spark" text="generate" size={40} hot /></Pop>
    </AbsoluteFill>
  );
};

/** Shutterstock / Freepik -> dollar; then "no design skill needed" */
export const S4bMarkets: React.FC = () => {
  const f = useCurrentFrame();
  const at = useAt();
  const a = at(17, 0), b = at(17, 2), sell = at(17, 3), usd = at(18, 0);
  const g = at(19, 0, 6);
  const strike = at(19, 3);
  const line = (x1: number, y1: number, x2: number, y2: number, t: number) => {
    const p = ramp(f, t, t + 16, [0, 1], theme.ease.inOut);
    const k = (f * 0.03) % 1;
    return <g opacity={p}><line x1={x1} y1={y1} x2={x2} y2={y2} stroke={theme.colors.primary} strokeOpacity={0.5} strokeWidth={4} strokeDasharray="12 12" strokeDashoffset={-f} strokeLinecap="round" /><circle cx={x1 + (x2 - x1) * k} cy={y1 + (y2 - y1) * k} r={9} fill={theme.colors.primary} /></g>;
  };
  return (
    <AbsoluteFill>
      <Sfx at={a} name="pluck" vol={0.28} />
      <Sfx at={b} name="pluck" vol={0.28} rate={1.07} />
      <Sfx at={usd} name="chime" vol={0.3} />
      <Sfx at={strike} name="click" vol={0.3} />
      <Exit at={g}>
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
          {line(680, 470, 860, 590, sell)}
          {line(1325, 470, 1100, 590, sell + 4)}
        </svg>
        <Pop at={a} from={{ x: -80, s: 0.8 }} preset="bouncy" style={{ position: "absolute", left: 455, top: 150 + Math.sin(f / 26) * 6 }}><LogoCard logo="shutterstock" h={300} radius={36} glow /></Pop>
        <Pop at={at(17, 1)} from={{ s: 0.3 }} preset="bouncy" style={{ position: "absolute", left: 915, top: 270 }}>
          <div style={{ width: 90, height: 90, borderRadius: 90, background: theme.colors.surface, border: `1px solid ${theme.colors.border}`, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 44, color: theme.colors.textDim }}>বা</div>
        </Pop>
        <Pop at={b} from={{ x: 80, s: 0.8 }} preset="bouncy" style={{ position: "absolute", left: 1125, top: 150 + Math.sin(f / 26 + 2) * 6 }}><LogoCard logo="freepik" h={300} radius={36} /></Pop>
        <Chip at={sell} icon="upload" text="sell" size={44} style={{ position: "absolute", left: 850, top: 455 }} />
        <Pop at={usd - 8} from={{ y: 60, s: 0.92 }} style={{ position: "absolute", left: 330, top: 590 }}>
          <Glass style={{ width: 1260, height: 330 }} radius={48}>
            <div style={{ display: "flex", height: "100%", alignItems: "center", justifyContent: "center", gap: 70 }}>
              <Coin size={200} spin={0.7} />
              <Words text="dollar আয়" at={0} times={[at(18, 0), at(18, 1)]} size={140} hi={[0]} glow />
            </div>
          </Glass>
        </Pop>
        <CoinBurst at={usd} cx={960} cy={760} count={14} />
      </Exit>
      {/* no design skill needed */}
      <Pop at={g + 4} from={{ y: 60, s: 0.85 }} preset="bouncy" style={{ position: "absolute", left: 480, top: 250 }}>
        <Glass style={{ width: 960, height: 230 }} radius={56}>
          <div style={{ display: "flex", height: "100%", alignItems: "center", justifyContent: "center", gap: 36, position: "relative" }}>
            <Icon name="pen" size={110} color={theme.colors.textDim} />
            <div style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 92, color: theme.colors.textDim, lineHeight: 1.3 }}>Graphics Design</div>
            <div style={{ position: "absolute", left: 90, top: 112, height: 10, width: 780 * ramp(f, strike, strike + 9), borderRadius: 6, background: theme.colors.accent }} />
          </div>
        </Glass>
      </Pop>
      <Pop at={strike + 6} from={{ s: 0.2 }} preset="bouncy" style={{ position: "absolute", left: 1390, top: 205 }}>
        <div style={{ width: 90, height: 90, borderRadius: 90, background: theme.colors.accent, display: "flex", alignItems: "center", justifyContent: "center" }}><Icon name="cross" size={54} color={theme.colors.ink} stroke={3.4} /></div>
      </Pop>
      <div style={{ position: "absolute", left: 0, right: 0, top: 580, display: "flex", justifyContent: "center" }}>
        <Words text="শেখার প্রয়োজনই নেই" at={0} times={[at(19, 3), at(19, 4), at(20, 0)]} size={118} hi={[2]} glow />
      </div>
    </AbsoluteFill>
  );
};
