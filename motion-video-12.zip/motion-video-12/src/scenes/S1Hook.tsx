import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme, gold } from "../theme";
import { Coin, Icon, Pop, Sfx, Words, ramp, useAt } from "../components/core";
import { Chip } from "../components/parts";

export const S1Hook: React.FC = () => {
  const f = useCurrentFrame();
  const at = useAt();
  const bOut = at(2, 1, 0); // beat A leaves when "এই" is spoken
  const l1 = [0, 1, 2, 3].map((i) => at(1, i));
  const l2 = [4, 5, 6].map((i) => at(1, i)).concat([at(2, 0)]);
  const num = at(2, 2);
  const digit = Math.min(3, Math.floor(ramp(f, num, num + 18, [0, 3.99], theme.ease.inOut)));
  const wob = Math.sin(f * 0.9) * (f > l2[0] && f < at(2, 0) ? 7 : 0);
  const crossed = f >= at(2, 0);
  return (
    <AbsoluteFill>
      <Sfx at={2} name="thud" vol={0.26} />
      <Sfx at={at(2, 0)} name="pop" vol={0.28} />
      <Sfx at={at(2, 1, 4)} name="whoosh" vol={0.24} />
      {/* ---- beat A: the problem ---- */}
      <Pop at={0} from={{ y: 0, s: 0.7 }} out={bOut} style={{ position: "absolute", left: 660, top: 190 }}>
        <div style={{ width: 600, height: 600, borderRadius: 600, border: `3px dashed ${theme.colors.border}`, transform: `rotate(${f * 0.5}deg)`, opacity: 0.8 }} />
      </Pop>
      <div style={{ position: "absolute", left: 0, right: 0, top: 215, display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
        <Words text="কোন skill নেই বলে" at={0} times={l1} size={156} hi={[1]} glow out={bOut} />
        <div style={{ display: "flex", alignItems: "center", gap: 0 }}>
          <Words text="টাকা কামাতে পারছেন না?" at={0} times={l2} size={156} out={bOut} dim={[]} style={{ transform: `translateX(${wob}px)` }} />
        </div>
      </div>
      <Pop at={at(1, 4, 0)} from={{ y: 50 }} out={bOut} style={{ position: "absolute", left: 470, top: 745, width: 980 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 28 }}>
          <div style={{ fontFamily: theme.fonts.body, fontWeight: 700, fontSize: 40, color: theme.colors.textDim, width: 110 }}>skill</div>
          <div style={{ flex: 1, height: 22, borderRadius: 22, background: theme.colors.surfaceHi, overflow: "hidden", border: `1px solid ${theme.colors.border}` }}>
            <div style={{ width: `${3 + 2.5 * Math.abs(Math.sin(f / 7))}%`, height: "100%", background: theme.colors.accent, borderRadius: 22 }} />
          </div>
          <div style={{ position: "relative", width: 100, height: 100 }}>
            <div style={{ filter: crossed ? "grayscale(1) brightness(0.6)" : "none" }}><Coin size={100} spin={crossed ? 0 : 1.2} /></div>
            {crossed && <Pop at={at(2, 0, 0)} from={{ s: 0.2 }} preset="bouncy" style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}><Icon name="cross" size={92} color={theme.colors.accent} stroke={2.6} /></Pop>}
          </div>
        </div>
      </Pop>
      {/* ---- beat B: three AI tools ---- */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 150, display: "flex", justifyContent: "center" }}>
        <Words text="এই তিনটি" at={at(2, 1)} per={5} size={84} color={theme.colors.textDim} />
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 290, display: "flex", justifyContent: "center", alignItems: "center", gap: 90 }}>
        <Pop at={num} from={{ y: 70, s: 0.7 }} preset="bouncy">
          <div style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 500, lineHeight: 1, backgroundImage: gold, WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent", fontVariantNumeric: "tabular-nums", filter: `drop-shadow(0 0 60px ${theme.colors.glow})`, paddingBottom: 30 }}>{`0${digit}`}</div>
        </Pop>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 0 }}>
          <Words text="powerful" at={0} times={[at(2, 3)]} size={150} align="left" />
          <Words text="AI tool" at={0} times={[at(2, 4), at(2, 5)]} size={150} align="left" hi={[0]} />
        </div>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 850, display: "flex", justifyContent: "center", gap: 34 }}>
        {[0, 1, 2].map((i) => <Chip key={i} at={at(2, 3) + 2 + i * 5} icon="spark" text="AI" size={44} />)}
      </div>
    </AbsoluteFill>
  );
};
