// Logo registry (files in public/logos). Aspect ratios are the files' natural ones — never distorted.
export const logos = {
  fliki: { src: "logos/fliki.jpg", w: 764, h: 401 },
  midjourney: { src: "logos/midjourney.jpg", w: 640, h: 480 },
  bookbolt: { src: "logos/bookbolt.png", w: 554, h: 554 },
  shutterstock: { src: "logos/shutterstock.png", w: 600, h: 400 },
  freepik: { src: "logos/freepik.png", w: 516, h: 387 },
  amazon: { src: "logos/amazon.png", w: 1920, h: 1465 },
  youtube: { src: "logos/youtube.jpg", w: 739, h: 415 },
} as const;
export type LogoKey = keyof typeof logos;
