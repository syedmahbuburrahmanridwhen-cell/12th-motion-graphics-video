// All timing derives from the SRT (src/cues.generated.ts). Cue numbers are 1-based like the SRT.
import { cues } from "./cues.generated";
export const FPS = 30;
export const W = 1920;
export const H = 1080;
export const VIS_LEAD = 5; // visuals land ~5 frames before the spoken word
export const TOTAL = Math.round(cues[cues.length - 1].end * FPS);

export const cueFrame = (i: number) => Math.round(cues[i - 1].start * FPS);
export const cueEndFrame = (i: number) => Math.round(cues[i - 1].end * FPS);
const toks = (i: number) => cues[i - 1].text.split(" ");
/** Estimated frame at which word `w` of cue `i` is spoken (spread proportionally to word length inside the cue). */
export const wordFrame = (i: number, w = 0) => {
  const ws = toks(i).map((t) => [...t].length + 1);
  const tot = ws.reduce((a, b) => a + b, 0);
  const before = ws.slice(0, w).reduce((a, b) => a + b, 0);
  const a = cues[i - 1].start * FPS, b = cues[i - 1].end * FPS;
  return Math.round(a + ((b - a) * before) / tot);
};
