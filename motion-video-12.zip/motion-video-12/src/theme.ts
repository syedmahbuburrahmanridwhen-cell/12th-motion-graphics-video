// theme.ts — single source of truth: colors, fonts, easing, springs. Scheme: Graphite Gold (dark).
import { Easing } from "remotion";

export const theme = {
  colors: {
    bg: "#0E0E0F",
    bgAlt: "#17171A",
    surface: "#1D1D21",
    surfaceHi: "#27272C",
    border: "rgba(250,246,236,0.10)",
    primary: "#F5B93A", // hero (gold)
    accent: "#FF7A45", // accent (orange)
    text: "#FAF6EC",
    textDim: "#A8A294",
    ink: "#141414", // dark text on light/gold surfaces
    paper: "#FAF6EC",
    glow: "rgba(245,185,58,0.40)",
    glowSoft: "rgba(245,185,58,0.16)",
    accentSoft: "rgba(255,122,69,0.18)",
  },
  fonts: { display: "'Hind Siliguri', 'Noto Sans Bengali', sans-serif", body: "'Hind Siliguri', 'Noto Sans Bengali', sans-serif" },
  radius: { sm: 16, md: 28, lg: 40 },
  shadow: { card: "0 30px 70px -24px rgba(0,0,0,0.75), 0 2px 0 rgba(250,246,236,0.05) inset", pop: "0 18px 40px -14px rgba(0,0,0,0.7)" },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
    wipe: Easing.bezier(0.65, 0, 0.35, 1),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
  motion: { wordStagger: 4, enterFrames: 20, exitFrames: 10 },
} as const;

export const gold = `linear-gradient(135deg, #FFD770 0%, ${theme.colors.primary} 45%, #E39A1C 100%)`;
